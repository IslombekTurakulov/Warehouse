﻿
using System.Drawing;

namespace Warehouse
{
    partial class AddFileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation1 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddFileForm));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.bunifuFormDock = new Bunifu.UI.WinForms.BunifuFormDock();
            this.controlPage = new Bunifu.UI.WinForms.BunifuPages();
            this.mainFunc = new System.Windows.Forms.TabPage();
            this.booleanRandomButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.digitsRandomButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.countryRandomButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.codeRandomButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.randomNameButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.companyTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.resultDiscountLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.cancelButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.okButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.applyButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.randomUcnButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.discountLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.discountTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.statusLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.statusDropdown = new Bunifu.UI.WinForms.BunifuDropdown();
            this.warrantyLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.warrantyDropdown = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuSeparator1 = new Bunifu.UI.WinForms.BunifuSeparator();
            this.currencyLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.currencyDropdown = new Bunifu.UI.WinForms.BunifuDropdown();
            this.firstCostTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.costLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.amountTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.amountLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.separator = new Bunifu.UI.WinForms.BunifuSeparator();
            this.countryDropdown = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.companyLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.ucnTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.ucnLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.codeLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.codeTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.nameLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.nameTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.extraFunc = new System.Windows.Forms.TabPage();
            this.descriptionTxtBox = new System.Windows.Forms.RichTextBox();
            this.descriptionLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.editImageButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.imageLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.imageFileBox = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.panelSettings = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.secondTopPanel = new Bunifu.UI.WinForms.BunifuPanel();
            this.extraFuncButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.mainFuncButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.topbarPanel = new Bunifu.UI.WinForms.BunifuPanel();
            this.exitButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.controlPage.SuspendLayout();
            this.mainFunc.SuspendLayout();
            this.extraFunc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageFileBox)).BeginInit();
            this.panelSettings.SuspendLayout();
            this.secondTopPanel.SuspendLayout();
            this.topbarPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuFormDock
            // 
            this.bunifuFormDock.AllowFormDragging = true;
            this.bunifuFormDock.AllowFormDropShadow = true;
            this.bunifuFormDock.AllowFormResizing = true;
            this.bunifuFormDock.AllowHidingBottomRegion = true;
            this.bunifuFormDock.AllowOpacityChangesWhileDragging = false;
            this.bunifuFormDock.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock.ContainerControl = this;
            this.bunifuFormDock.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock.DockingOptions.DockAll = true;
            this.bunifuFormDock.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock.DockingOptions.DockLeft = true;
            this.bunifuFormDock.DockingOptions.DockRight = true;
            this.bunifuFormDock.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock.DockingOptions.DockTopRight = true;
            this.bunifuFormDock.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock.ParentForm = this;
            this.bunifuFormDock.ShowCursorChanges = true;
            this.bunifuFormDock.ShowDockingIndicators = true;
            this.bunifuFormDock.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock.TitleBarOptions.BunifuFormDock = this.bunifuFormDock;
            this.bunifuFormDock.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // controlPage
            // 
            this.controlPage.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.controlPage.AllowTransitions = true;
            this.controlPage.Controls.Add(this.mainFunc);
            this.controlPage.Controls.Add(this.extraFunc);
            this.controlPage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.controlPage.Location = new System.Drawing.Point(0, 0);
            this.controlPage.Multiline = true;
            this.controlPage.Name = "controlPage";
            this.controlPage.Page = this.mainFunc;
            this.controlPage.PageIndex = 0;
            this.controlPage.PageName = "mainFunc";
            this.controlPage.PageTitle = "Main Function";
            this.controlPage.SelectedIndex = 0;
            this.controlPage.Size = new System.Drawing.Size(816, 428);
            this.controlPage.TabIndex = 1;
            animation1.AnimateOnlyDifferences = false;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.controlPage.Transition = animation1;
            this.controlPage.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // mainFunc
            // 
            this.mainFunc.Controls.Add(this.booleanRandomButton);
            this.mainFunc.Controls.Add(this.digitsRandomButton);
            this.mainFunc.Controls.Add(this.countryRandomButton);
            this.mainFunc.Controls.Add(this.codeRandomButton);
            this.mainFunc.Controls.Add(this.randomNameButton);
            this.mainFunc.Controls.Add(this.companyTxtBox);
            this.mainFunc.Controls.Add(this.resultDiscountLabel);
            this.mainFunc.Controls.Add(this.cancelButton);
            this.mainFunc.Controls.Add(this.okButton);
            this.mainFunc.Controls.Add(this.applyButton);
            this.mainFunc.Controls.Add(this.randomUcnButton);
            this.mainFunc.Controls.Add(this.discountLabel);
            this.mainFunc.Controls.Add(this.discountTxtBox);
            this.mainFunc.Controls.Add(this.statusLabel);
            this.mainFunc.Controls.Add(this.statusDropdown);
            this.mainFunc.Controls.Add(this.warrantyLabel);
            this.mainFunc.Controls.Add(this.warrantyDropdown);
            this.mainFunc.Controls.Add(this.bunifuSeparator1);
            this.mainFunc.Controls.Add(this.currencyLabel);
            this.mainFunc.Controls.Add(this.currencyDropdown);
            this.mainFunc.Controls.Add(this.firstCostTxtBox);
            this.mainFunc.Controls.Add(this.costLabel);
            this.mainFunc.Controls.Add(this.amountTxtBox);
            this.mainFunc.Controls.Add(this.amountLabel);
            this.mainFunc.Controls.Add(this.separator);
            this.mainFunc.Controls.Add(this.countryDropdown);
            this.mainFunc.Controls.Add(this.bunifuLabel4);
            this.mainFunc.Controls.Add(this.companyLabel);
            this.mainFunc.Controls.Add(this.ucnTxtBox);
            this.mainFunc.Controls.Add(this.ucnLabel);
            this.mainFunc.Controls.Add(this.codeLabel);
            this.mainFunc.Controls.Add(this.codeTxtBox);
            this.mainFunc.Controls.Add(this.nameLabel);
            this.mainFunc.Controls.Add(this.nameTxtBox);
            this.mainFunc.Location = new System.Drawing.Point(4, 4);
            this.mainFunc.Name = "mainFunc";
            this.mainFunc.Padding = new System.Windows.Forms.Padding(3);
            this.mainFunc.Size = new System.Drawing.Size(808, 402);
            this.mainFunc.TabIndex = 0;
            this.mainFunc.Text = "Main Function";
            this.mainFunc.ToolTipText = "Основные Свойства";
            this.mainFunc.UseVisualStyleBackColor = true;
            // 
            // booleanRandomButton
            // 
            this.booleanRandomButton.AllowAnimations = true;
            this.booleanRandomButton.AllowMouseEffects = true;
            this.booleanRandomButton.AllowToggling = true;
            this.booleanRandomButton.AnimationSpeed = 200;
            this.booleanRandomButton.AutoGenerateColors = false;
            this.booleanRandomButton.AutoRoundBorders = false;
            this.booleanRandomButton.AutoSizeLeftIcon = true;
            this.booleanRandomButton.AutoSizeRightIcon = true;
            this.booleanRandomButton.BackColor = System.Drawing.Color.Transparent;
            this.booleanRandomButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.booleanRandomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("booleanRandomButton.BackgroundImage")));
            this.booleanRandomButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.booleanRandomButton.ButtonText = "Random";
            this.booleanRandomButton.ButtonTextMarginLeft = 0;
            this.booleanRandomButton.ColorContrastOnClick = 45;
            this.booleanRandomButton.ColorContrastOnHover = 45;
            this.booleanRandomButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.booleanRandomButton.CustomizableEdges = borderEdges1;
            this.booleanRandomButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.booleanRandomButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.booleanRandomButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.booleanRandomButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.booleanRandomButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.booleanRandomButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.booleanRandomButton.ForeColor = System.Drawing.Color.DimGray;
            this.booleanRandomButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.booleanRandomButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.booleanRandomButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.booleanRandomButton.IconMarginLeft = 11;
            this.booleanRandomButton.IconPadding = 13;
            this.booleanRandomButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.booleanRandomButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.booleanRandomButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.booleanRandomButton.IconSize = 25;
            this.booleanRandomButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.booleanRandomButton.IdleBorderRadius = 1;
            this.booleanRandomButton.IdleBorderThickness = 1;
            this.booleanRandomButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.booleanRandomButton.IdleIconLeftImage = null;
            this.booleanRandomButton.IdleIconRightImage = null;
            this.booleanRandomButton.IndicateFocus = true;
            this.booleanRandomButton.Location = new System.Drawing.Point(265, 299);
            this.booleanRandomButton.Name = "booleanRandomButton";
            this.booleanRandomButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.booleanRandomButton.OnDisabledState.BorderRadius = 1;
            this.booleanRandomButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.booleanRandomButton.OnDisabledState.BorderThickness = 1;
            this.booleanRandomButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.booleanRandomButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.booleanRandomButton.OnDisabledState.IconLeftImage = null;
            this.booleanRandomButton.OnDisabledState.IconRightImage = null;
            this.booleanRandomButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.booleanRandomButton.onHoverState.BorderRadius = 1;
            this.booleanRandomButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.booleanRandomButton.onHoverState.BorderThickness = 1;
            this.booleanRandomButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.booleanRandomButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.booleanRandomButton.onHoverState.IconLeftImage = null;
            this.booleanRandomButton.onHoverState.IconRightImage = null;
            this.booleanRandomButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.booleanRandomButton.OnIdleState.BorderRadius = 1;
            this.booleanRandomButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.booleanRandomButton.OnIdleState.BorderThickness = 1;
            this.booleanRandomButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.booleanRandomButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.booleanRandomButton.OnIdleState.IconLeftImage = null;
            this.booleanRandomButton.OnIdleState.IconRightImage = null;
            this.booleanRandomButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.booleanRandomButton.OnPressedState.BorderRadius = 1;
            this.booleanRandomButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.booleanRandomButton.OnPressedState.BorderThickness = 1;
            this.booleanRandomButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.booleanRandomButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.booleanRandomButton.OnPressedState.IconLeftImage = null;
            this.booleanRandomButton.OnPressedState.IconRightImage = null;
            this.booleanRandomButton.Size = new System.Drawing.Size(94, 25);
            this.booleanRandomButton.TabIndex = 49;
            this.booleanRandomButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.booleanRandomButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.booleanRandomButton.TextMarginLeft = 0;
            this.booleanRandomButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.booleanRandomButton.UseDefaultRadiusAndThickness = true;
            this.booleanRandomButton.Click += new System.EventHandler(this.booleanRandomButton_Click);
            // 
            // digitsRandomButton
            // 
            this.digitsRandomButton.AllowAnimations = true;
            this.digitsRandomButton.AllowMouseEffects = true;
            this.digitsRandomButton.AllowToggling = true;
            this.digitsRandomButton.AnimationSpeed = 200;
            this.digitsRandomButton.AutoGenerateColors = false;
            this.digitsRandomButton.AutoRoundBorders = false;
            this.digitsRandomButton.AutoSizeLeftIcon = true;
            this.digitsRandomButton.AutoSizeRightIcon = true;
            this.digitsRandomButton.BackColor = System.Drawing.Color.Transparent;
            this.digitsRandomButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.digitsRandomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("digitsRandomButton.BackgroundImage")));
            this.digitsRandomButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.digitsRandomButton.ButtonText = "Random";
            this.digitsRandomButton.ButtonTextMarginLeft = 0;
            this.digitsRandomButton.ColorContrastOnClick = 45;
            this.digitsRandomButton.ColorContrastOnHover = 45;
            this.digitsRandomButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.digitsRandomButton.CustomizableEdges = borderEdges2;
            this.digitsRandomButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.digitsRandomButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.digitsRandomButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.digitsRandomButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.digitsRandomButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.digitsRandomButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.digitsRandomButton.ForeColor = System.Drawing.Color.DimGray;
            this.digitsRandomButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.digitsRandomButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.digitsRandomButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.digitsRandomButton.IconMarginLeft = 11;
            this.digitsRandomButton.IconPadding = 13;
            this.digitsRandomButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.digitsRandomButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.digitsRandomButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.digitsRandomButton.IconSize = 25;
            this.digitsRandomButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.digitsRandomButton.IdleBorderRadius = 1;
            this.digitsRandomButton.IdleBorderThickness = 1;
            this.digitsRandomButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.digitsRandomButton.IdleIconLeftImage = null;
            this.digitsRandomButton.IdleIconRightImage = null;
            this.digitsRandomButton.IndicateFocus = true;
            this.digitsRandomButton.Location = new System.Drawing.Point(698, 215);
            this.digitsRandomButton.Name = "digitsRandomButton";
            this.digitsRandomButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.digitsRandomButton.OnDisabledState.BorderRadius = 1;
            this.digitsRandomButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.digitsRandomButton.OnDisabledState.BorderThickness = 1;
            this.digitsRandomButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.digitsRandomButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.digitsRandomButton.OnDisabledState.IconLeftImage = null;
            this.digitsRandomButton.OnDisabledState.IconRightImage = null;
            this.digitsRandomButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.digitsRandomButton.onHoverState.BorderRadius = 1;
            this.digitsRandomButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.digitsRandomButton.onHoverState.BorderThickness = 1;
            this.digitsRandomButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.digitsRandomButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.digitsRandomButton.onHoverState.IconLeftImage = null;
            this.digitsRandomButton.onHoverState.IconRightImage = null;
            this.digitsRandomButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.digitsRandomButton.OnIdleState.BorderRadius = 1;
            this.digitsRandomButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.digitsRandomButton.OnIdleState.BorderThickness = 1;
            this.digitsRandomButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.digitsRandomButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.digitsRandomButton.OnIdleState.IconLeftImage = null;
            this.digitsRandomButton.OnIdleState.IconRightImage = null;
            this.digitsRandomButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.digitsRandomButton.OnPressedState.BorderRadius = 1;
            this.digitsRandomButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.digitsRandomButton.OnPressedState.BorderThickness = 1;
            this.digitsRandomButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.digitsRandomButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.digitsRandomButton.OnPressedState.IconLeftImage = null;
            this.digitsRandomButton.OnPressedState.IconRightImage = null;
            this.digitsRandomButton.Size = new System.Drawing.Size(94, 25);
            this.digitsRandomButton.TabIndex = 48;
            this.digitsRandomButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.digitsRandomButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.digitsRandomButton.TextMarginLeft = 0;
            this.digitsRandomButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.digitsRandomButton.UseDefaultRadiusAndThickness = true;
            this.digitsRandomButton.Click += new System.EventHandler(this.digitsRandomButton_Click);
            // 
            // countryRandomButton
            // 
            this.countryRandomButton.AllowAnimations = true;
            this.countryRandomButton.AllowMouseEffects = true;
            this.countryRandomButton.AllowToggling = true;
            this.countryRandomButton.AnimationSpeed = 200;
            this.countryRandomButton.AutoGenerateColors = false;
            this.countryRandomButton.AutoRoundBorders = false;
            this.countryRandomButton.AutoSizeLeftIcon = true;
            this.countryRandomButton.AutoSizeRightIcon = true;
            this.countryRandomButton.BackColor = System.Drawing.Color.Transparent;
            this.countryRandomButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.countryRandomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("countryRandomButton.BackgroundImage")));
            this.countryRandomButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.countryRandomButton.ButtonText = "Random Country";
            this.countryRandomButton.ButtonTextMarginLeft = 0;
            this.countryRandomButton.ColorContrastOnClick = 45;
            this.countryRandomButton.ColorContrastOnHover = 45;
            this.countryRandomButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.countryRandomButton.CustomizableEdges = borderEdges3;
            this.countryRandomButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.countryRandomButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.countryRandomButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.countryRandomButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.countryRandomButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.countryRandomButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.countryRandomButton.ForeColor = System.Drawing.Color.DimGray;
            this.countryRandomButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.countryRandomButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.countryRandomButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.countryRandomButton.IconMarginLeft = 11;
            this.countryRandomButton.IconPadding = 13;
            this.countryRandomButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.countryRandomButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.countryRandomButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.countryRandomButton.IconSize = 25;
            this.countryRandomButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.countryRandomButton.IdleBorderRadius = 1;
            this.countryRandomButton.IdleBorderThickness = 1;
            this.countryRandomButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.countryRandomButton.IdleIconLeftImage = null;
            this.countryRandomButton.IdleIconRightImage = null;
            this.countryRandomButton.IndicateFocus = true;
            this.countryRandomButton.Location = new System.Drawing.Point(356, 148);
            this.countryRandomButton.Name = "countryRandomButton";
            this.countryRandomButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.countryRandomButton.OnDisabledState.BorderRadius = 1;
            this.countryRandomButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.countryRandomButton.OnDisabledState.BorderThickness = 1;
            this.countryRandomButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.countryRandomButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.countryRandomButton.OnDisabledState.IconLeftImage = null;
            this.countryRandomButton.OnDisabledState.IconRightImage = null;
            this.countryRandomButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.countryRandomButton.onHoverState.BorderRadius = 1;
            this.countryRandomButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.countryRandomButton.onHoverState.BorderThickness = 1;
            this.countryRandomButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.countryRandomButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.countryRandomButton.onHoverState.IconLeftImage = null;
            this.countryRandomButton.onHoverState.IconRightImage = null;
            this.countryRandomButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.countryRandomButton.OnIdleState.BorderRadius = 1;
            this.countryRandomButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.countryRandomButton.OnIdleState.BorderThickness = 1;
            this.countryRandomButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.countryRandomButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.countryRandomButton.OnIdleState.IconLeftImage = null;
            this.countryRandomButton.OnIdleState.IconRightImage = null;
            this.countryRandomButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.countryRandomButton.OnPressedState.BorderRadius = 1;
            this.countryRandomButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.countryRandomButton.OnPressedState.BorderThickness = 1;
            this.countryRandomButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.countryRandomButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.countryRandomButton.OnPressedState.IconLeftImage = null;
            this.countryRandomButton.OnPressedState.IconRightImage = null;
            this.countryRandomButton.Size = new System.Drawing.Size(141, 25);
            this.countryRandomButton.TabIndex = 47;
            this.countryRandomButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.countryRandomButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.countryRandomButton.TextMarginLeft = 0;
            this.countryRandomButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.countryRandomButton.UseDefaultRadiusAndThickness = true;
            this.countryRandomButton.Click += new System.EventHandler(this.countryRandomButton_Click);
            // 
            // codeRandomButton
            // 
            this.codeRandomButton.AllowAnimations = true;
            this.codeRandomButton.AllowMouseEffects = true;
            this.codeRandomButton.AllowToggling = true;
            this.codeRandomButton.AnimationSpeed = 200;
            this.codeRandomButton.AutoGenerateColors = false;
            this.codeRandomButton.AutoRoundBorders = false;
            this.codeRandomButton.AutoSizeLeftIcon = true;
            this.codeRandomButton.AutoSizeRightIcon = true;
            this.codeRandomButton.BackColor = System.Drawing.Color.Transparent;
            this.codeRandomButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.codeRandomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("codeRandomButton.BackgroundImage")));
            this.codeRandomButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.codeRandomButton.ButtonText = "Random";
            this.codeRandomButton.ButtonTextMarginLeft = 0;
            this.codeRandomButton.ColorContrastOnClick = 45;
            this.codeRandomButton.ColorContrastOnHover = 45;
            this.codeRandomButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.codeRandomButton.CustomizableEdges = borderEdges4;
            this.codeRandomButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.codeRandomButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.codeRandomButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.codeRandomButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.codeRandomButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.codeRandomButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.codeRandomButton.ForeColor = System.Drawing.Color.DimGray;
            this.codeRandomButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.codeRandomButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.codeRandomButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.codeRandomButton.IconMarginLeft = 11;
            this.codeRandomButton.IconPadding = 13;
            this.codeRandomButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.codeRandomButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.codeRandomButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.codeRandomButton.IconSize = 25;
            this.codeRandomButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.codeRandomButton.IdleBorderRadius = 1;
            this.codeRandomButton.IdleBorderThickness = 1;
            this.codeRandomButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.codeRandomButton.IdleIconLeftImage = null;
            this.codeRandomButton.IdleIconRightImage = null;
            this.codeRandomButton.IndicateFocus = true;
            this.codeRandomButton.Location = new System.Drawing.Point(325, 66);
            this.codeRandomButton.Name = "codeRandomButton";
            this.codeRandomButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.codeRandomButton.OnDisabledState.BorderRadius = 1;
            this.codeRandomButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.codeRandomButton.OnDisabledState.BorderThickness = 1;
            this.codeRandomButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.codeRandomButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.codeRandomButton.OnDisabledState.IconLeftImage = null;
            this.codeRandomButton.OnDisabledState.IconRightImage = null;
            this.codeRandomButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.codeRandomButton.onHoverState.BorderRadius = 1;
            this.codeRandomButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.codeRandomButton.onHoverState.BorderThickness = 1;
            this.codeRandomButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.codeRandomButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.codeRandomButton.onHoverState.IconLeftImage = null;
            this.codeRandomButton.onHoverState.IconRightImage = null;
            this.codeRandomButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.codeRandomButton.OnIdleState.BorderRadius = 1;
            this.codeRandomButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.codeRandomButton.OnIdleState.BorderThickness = 1;
            this.codeRandomButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.codeRandomButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.codeRandomButton.OnIdleState.IconLeftImage = null;
            this.codeRandomButton.OnIdleState.IconRightImage = null;
            this.codeRandomButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.codeRandomButton.OnPressedState.BorderRadius = 1;
            this.codeRandomButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.codeRandomButton.OnPressedState.BorderThickness = 1;
            this.codeRandomButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.codeRandomButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.codeRandomButton.OnPressedState.IconLeftImage = null;
            this.codeRandomButton.OnPressedState.IconRightImage = null;
            this.codeRandomButton.Size = new System.Drawing.Size(83, 25);
            this.codeRandomButton.TabIndex = 46;
            this.codeRandomButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.codeRandomButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.codeRandomButton.TextMarginLeft = 0;
            this.codeRandomButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.codeRandomButton.UseDefaultRadiusAndThickness = true;
            this.codeRandomButton.Click += new System.EventHandler(this.codeRandomButton_Click);
            // 
            // randomNameButton
            // 
            this.randomNameButton.AllowAnimations = true;
            this.randomNameButton.AllowMouseEffects = true;
            this.randomNameButton.AllowToggling = true;
            this.randomNameButton.AnimationSpeed = 200;
            this.randomNameButton.AutoGenerateColors = false;
            this.randomNameButton.AutoRoundBorders = false;
            this.randomNameButton.AutoSizeLeftIcon = true;
            this.randomNameButton.AutoSizeRightIcon = true;
            this.randomNameButton.BackColor = System.Drawing.Color.Transparent;
            this.randomNameButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.randomNameButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("randomNameButton.BackgroundImage")));
            this.randomNameButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomNameButton.ButtonText = "Random Name";
            this.randomNameButton.ButtonTextMarginLeft = 0;
            this.randomNameButton.ColorContrastOnClick = 45;
            this.randomNameButton.ColorContrastOnHover = 45;
            this.randomNameButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.randomNameButton.CustomizableEdges = borderEdges5;
            this.randomNameButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.randomNameButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.randomNameButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.randomNameButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.randomNameButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.randomNameButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.randomNameButton.ForeColor = System.Drawing.Color.DimGray;
            this.randomNameButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.randomNameButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.randomNameButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.randomNameButton.IconMarginLeft = 11;
            this.randomNameButton.IconPadding = 13;
            this.randomNameButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.randomNameButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.randomNameButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.randomNameButton.IconSize = 25;
            this.randomNameButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.randomNameButton.IdleBorderRadius = 1;
            this.randomNameButton.IdleBorderThickness = 1;
            this.randomNameButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.randomNameButton.IdleIconLeftImage = null;
            this.randomNameButton.IdleIconRightImage = null;
            this.randomNameButton.IndicateFocus = true;
            this.randomNameButton.Location = new System.Drawing.Point(532, 25);
            this.randomNameButton.Name = "randomNameButton";
            this.randomNameButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.randomNameButton.OnDisabledState.BorderRadius = 1;
            this.randomNameButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomNameButton.OnDisabledState.BorderThickness = 1;
            this.randomNameButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.randomNameButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.randomNameButton.OnDisabledState.IconLeftImage = null;
            this.randomNameButton.OnDisabledState.IconRightImage = null;
            this.randomNameButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.randomNameButton.onHoverState.BorderRadius = 1;
            this.randomNameButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomNameButton.onHoverState.BorderThickness = 1;
            this.randomNameButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.randomNameButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.randomNameButton.onHoverState.IconLeftImage = null;
            this.randomNameButton.onHoverState.IconRightImage = null;
            this.randomNameButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.randomNameButton.OnIdleState.BorderRadius = 1;
            this.randomNameButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomNameButton.OnIdleState.BorderThickness = 1;
            this.randomNameButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.randomNameButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.randomNameButton.OnIdleState.IconLeftImage = null;
            this.randomNameButton.OnIdleState.IconRightImage = null;
            this.randomNameButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.randomNameButton.OnPressedState.BorderRadius = 1;
            this.randomNameButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomNameButton.OnPressedState.BorderThickness = 1;
            this.randomNameButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.randomNameButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.randomNameButton.OnPressedState.IconLeftImage = null;
            this.randomNameButton.OnPressedState.IconRightImage = null;
            this.randomNameButton.Size = new System.Drawing.Size(122, 25);
            this.randomNameButton.TabIndex = 45;
            this.randomNameButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.randomNameButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.randomNameButton.TextMarginLeft = 0;
            this.randomNameButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.randomNameButton.UseDefaultRadiusAndThickness = true;
            this.randomNameButton.Click += new System.EventHandler(this.randomNameButton_Click);
            // 
            // companyTxtBox
            // 
            this.companyTxtBox.AcceptsReturn = false;
            this.companyTxtBox.AcceptsTab = false;
            this.companyTxtBox.AnimationSpeed = 200;
            this.companyTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.companyTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.companyTxtBox.BackColor = System.Drawing.Color.White;
            this.companyTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("companyTxtBox.BackgroundImage")));
            this.companyTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.companyTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.companyTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.companyTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.companyTxtBox.BorderRadius = 1;
            this.companyTxtBox.BorderThickness = 1;
            this.companyTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.companyTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.companyTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.companyTxtBox.DefaultText = "";
            this.companyTxtBox.FillColor = System.Drawing.Color.White;
            this.companyTxtBox.HideSelection = true;
            this.companyTxtBox.IconLeft = null;
            this.companyTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.companyTxtBox.IconPadding = 10;
            this.companyTxtBox.IconRight = null;
            this.companyTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.companyTxtBox.Lines = new string[0];
            this.companyTxtBox.Location = new System.Drawing.Point(90, 109);
            this.companyTxtBox.MaxLength = 32767;
            this.companyTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.companyTxtBox.Modified = false;
            this.companyTxtBox.Multiline = false;
            this.companyTxtBox.Name = "companyTxtBox";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.companyTxtBox.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.companyTxtBox.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.companyTxtBox.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.companyTxtBox.OnIdleState = stateProperties4;
            this.companyTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.companyTxtBox.PasswordChar = '\0';
            this.companyTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.companyTxtBox.PlaceholderText = "Enter company name";
            this.companyTxtBox.ReadOnly = false;
            this.companyTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.companyTxtBox.SelectedText = "";
            this.companyTxtBox.SelectionLength = 0;
            this.companyTxtBox.SelectionStart = 0;
            this.companyTxtBox.ShortcutsEnabled = true;
            this.companyTxtBox.Size = new System.Drawing.Size(280, 25);
            this.companyTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.companyTxtBox.TabIndex = 44;
            this.companyTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.companyTxtBox.TextMarginBottom = 0;
            this.companyTxtBox.TextMarginLeft = 3;
            this.companyTxtBox.TextMarginTop = 0;
            this.companyTxtBox.TextPlaceholder = "Enter company name";
            this.companyTxtBox.UseSystemPasswordChar = false;
            this.companyTxtBox.WordWrap = true;
            // 
            // resultDiscountLabel
            // 
            this.resultDiscountLabel.AllowParentOverrides = false;
            this.resultDiscountLabel.AutoEllipsis = false;
            this.resultDiscountLabel.CursorType = null;
            this.resultDiscountLabel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.resultDiscountLabel.Location = new System.Drawing.Point(463, 323);
            this.resultDiscountLabel.Name = "resultDiscountLabel";
            this.resultDiscountLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.resultDiscountLabel.Size = new System.Drawing.Size(103, 15);
            this.resultDiscountLabel.TabIndex = 43;
            this.resultDiscountLabel.Text = "Cost after discount: ";
            this.resultDiscountLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.resultDiscountLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.resultDiscountLabel.Visible = false;
            // 
            // cancelButton
            // 
            this.cancelButton.AllowAnimations = true;
            this.cancelButton.AllowMouseEffects = true;
            this.cancelButton.AllowToggling = true;
            this.cancelButton.AnimationSpeed = 200;
            this.cancelButton.AutoGenerateColors = false;
            this.cancelButton.AutoRoundBorders = false;
            this.cancelButton.AutoSizeLeftIcon = true;
            this.cancelButton.AutoSizeRightIcon = true;
            this.cancelButton.BackColor = System.Drawing.Color.Transparent;
            this.cancelButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.cancelButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cancelButton.BackgroundImage")));
            this.cancelButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cancelButton.ButtonText = "Cancel";
            this.cancelButton.ButtonTextMarginLeft = 0;
            this.cancelButton.ColorContrastOnClick = 45;
            this.cancelButton.ColorContrastOnHover = 45;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.cancelButton.CustomizableEdges = borderEdges6;
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.cancelButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.cancelButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cancelButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.cancelButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.cancelButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cancelButton.ForeColor = System.Drawing.Color.DimGray;
            this.cancelButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.cancelButton.IconMarginLeft = 11;
            this.cancelButton.IconPadding = 13;
            this.cancelButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cancelButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.cancelButton.IconSize = 25;
            this.cancelButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.cancelButton.IdleBorderRadius = 1;
            this.cancelButton.IdleBorderThickness = 1;
            this.cancelButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.cancelButton.IdleIconLeftImage = null;
            this.cancelButton.IdleIconRightImage = null;
            this.cancelButton.IndicateFocus = true;
            this.cancelButton.Location = new System.Drawing.Point(555, 372);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.cancelButton.OnDisabledState.BorderRadius = 1;
            this.cancelButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cancelButton.OnDisabledState.BorderThickness = 1;
            this.cancelButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cancelButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.cancelButton.OnDisabledState.IconLeftImage = null;
            this.cancelButton.OnDisabledState.IconRightImage = null;
            this.cancelButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.cancelButton.onHoverState.BorderRadius = 1;
            this.cancelButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cancelButton.onHoverState.BorderThickness = 1;
            this.cancelButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.cancelButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.cancelButton.onHoverState.IconLeftImage = null;
            this.cancelButton.onHoverState.IconRightImage = null;
            this.cancelButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.cancelButton.OnIdleState.BorderRadius = 1;
            this.cancelButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cancelButton.OnIdleState.BorderThickness = 1;
            this.cancelButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.cancelButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.cancelButton.OnIdleState.IconLeftImage = null;
            this.cancelButton.OnIdleState.IconRightImage = null;
            this.cancelButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.cancelButton.OnPressedState.BorderRadius = 1;
            this.cancelButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.cancelButton.OnPressedState.BorderThickness = 1;
            this.cancelButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.cancelButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.cancelButton.OnPressedState.IconLeftImage = null;
            this.cancelButton.OnPressedState.IconRightImage = null;
            this.cancelButton.Size = new System.Drawing.Size(122, 25);
            this.cancelButton.TabIndex = 41;
            this.cancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cancelButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.cancelButton.TextMarginLeft = 0;
            this.cancelButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.cancelButton.UseDefaultRadiusAndThickness = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // okButton
            // 
            this.okButton.AllowAnimations = true;
            this.okButton.AllowMouseEffects = true;
            this.okButton.AllowToggling = true;
            this.okButton.AnimationSpeed = 200;
            this.okButton.AutoGenerateColors = false;
            this.okButton.AutoRoundBorders = false;
            this.okButton.AutoSizeLeftIcon = true;
            this.okButton.AutoSizeRightIcon = true;
            this.okButton.BackColor = System.Drawing.Color.Transparent;
            this.okButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.okButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("okButton.BackgroundImage")));
            this.okButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.ButtonText = "OK";
            this.okButton.ButtonTextMarginLeft = 0;
            this.okButton.ColorContrastOnClick = 45;
            this.okButton.ColorContrastOnHover = 45;
            this.okButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges7.BottomLeft = true;
            borderEdges7.BottomRight = true;
            borderEdges7.TopLeft = true;
            borderEdges7.TopRight = true;
            this.okButton.CustomizableEdges = borderEdges7;
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.okButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.okButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.okButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.okButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.okButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.okButton.ForeColor = System.Drawing.Color.DimGray;
            this.okButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.okButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.okButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.okButton.IconMarginLeft = 11;
            this.okButton.IconPadding = 13;
            this.okButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.okButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.okButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.okButton.IconSize = 25;
            this.okButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.okButton.IdleBorderRadius = 1;
            this.okButton.IdleBorderThickness = 1;
            this.okButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.okButton.IdleIconLeftImage = null;
            this.okButton.IdleIconRightImage = null;
            this.okButton.IndicateFocus = true;
            this.okButton.Location = new System.Drawing.Point(427, 372);
            this.okButton.Name = "okButton";
            this.okButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.okButton.OnDisabledState.BorderRadius = 1;
            this.okButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.OnDisabledState.BorderThickness = 1;
            this.okButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.okButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.okButton.OnDisabledState.IconLeftImage = null;
            this.okButton.OnDisabledState.IconRightImage = null;
            this.okButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.okButton.onHoverState.BorderRadius = 1;
            this.okButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.onHoverState.BorderThickness = 1;
            this.okButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.okButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.okButton.onHoverState.IconLeftImage = null;
            this.okButton.onHoverState.IconRightImage = null;
            this.okButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.okButton.OnIdleState.BorderRadius = 1;
            this.okButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.OnIdleState.BorderThickness = 1;
            this.okButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.okButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.okButton.OnIdleState.IconLeftImage = null;
            this.okButton.OnIdleState.IconRightImage = null;
            this.okButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.okButton.OnPressedState.BorderRadius = 1;
            this.okButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.OnPressedState.BorderThickness = 1;
            this.okButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.okButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.okButton.OnPressedState.IconLeftImage = null;
            this.okButton.OnPressedState.IconRightImage = null;
            this.okButton.Size = new System.Drawing.Size(122, 25);
            this.okButton.TabIndex = 40;
            this.okButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.okButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.okButton.TextMarginLeft = 0;
            this.okButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.okButton.UseDefaultRadiusAndThickness = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.AllowAnimations = true;
            this.applyButton.AllowMouseEffects = true;
            this.applyButton.AllowToggling = true;
            this.applyButton.AnimationSpeed = 200;
            this.applyButton.AutoGenerateColors = false;
            this.applyButton.AutoRoundBorders = false;
            this.applyButton.AutoSizeLeftIcon = true;
            this.applyButton.AutoSizeRightIcon = true;
            this.applyButton.BackColor = System.Drawing.Color.Transparent;
            this.applyButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.applyButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("applyButton.BackgroundImage")));
            this.applyButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.applyButton.ButtonText = "Apply";
            this.applyButton.ButtonTextMarginLeft = 0;
            this.applyButton.ColorContrastOnClick = 45;
            this.applyButton.ColorContrastOnHover = 45;
            this.applyButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges8.BottomLeft = true;
            borderEdges8.BottomRight = true;
            borderEdges8.TopLeft = true;
            borderEdges8.TopRight = true;
            this.applyButton.CustomizableEdges = borderEdges8;
            this.applyButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.applyButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.applyButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.applyButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.applyButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.applyButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.applyButton.ForeColor = System.Drawing.Color.DimGray;
            this.applyButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.applyButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.applyButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.applyButton.IconMarginLeft = 11;
            this.applyButton.IconPadding = 13;
            this.applyButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.applyButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.applyButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.applyButton.IconSize = 25;
            this.applyButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.applyButton.IdleBorderRadius = 1;
            this.applyButton.IdleBorderThickness = 1;
            this.applyButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.applyButton.IdleIconLeftImage = null;
            this.applyButton.IdleIconRightImage = null;
            this.applyButton.IndicateFocus = true;
            this.applyButton.Location = new System.Drawing.Point(683, 372);
            this.applyButton.Name = "applyButton";
            this.applyButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.applyButton.OnDisabledState.BorderRadius = 1;
            this.applyButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.applyButton.OnDisabledState.BorderThickness = 1;
            this.applyButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.applyButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.applyButton.OnDisabledState.IconLeftImage = null;
            this.applyButton.OnDisabledState.IconRightImage = null;
            this.applyButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.applyButton.onHoverState.BorderRadius = 1;
            this.applyButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.applyButton.onHoverState.BorderThickness = 1;
            this.applyButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.applyButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.applyButton.onHoverState.IconLeftImage = null;
            this.applyButton.onHoverState.IconRightImage = null;
            this.applyButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.applyButton.OnIdleState.BorderRadius = 1;
            this.applyButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.applyButton.OnIdleState.BorderThickness = 1;
            this.applyButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.applyButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.applyButton.OnIdleState.IconLeftImage = null;
            this.applyButton.OnIdleState.IconRightImage = null;
            this.applyButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.applyButton.OnPressedState.BorderRadius = 1;
            this.applyButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.applyButton.OnPressedState.BorderThickness = 1;
            this.applyButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.applyButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.applyButton.OnPressedState.IconLeftImage = null;
            this.applyButton.OnPressedState.IconRightImage = null;
            this.applyButton.Size = new System.Drawing.Size(122, 25);
            this.applyButton.TabIndex = 39;
            this.applyButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.applyButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.applyButton.TextMarginLeft = 0;
            this.applyButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.applyButton.UseDefaultRadiusAndThickness = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // randomUcnButton
            // 
            this.randomUcnButton.AllowAnimations = true;
            this.randomUcnButton.AllowMouseEffects = true;
            this.randomUcnButton.AllowToggling = true;
            this.randomUcnButton.AnimationSpeed = 200;
            this.randomUcnButton.AutoGenerateColors = false;
            this.randomUcnButton.AutoRoundBorders = false;
            this.randomUcnButton.AutoSizeLeftIcon = true;
            this.randomUcnButton.AutoSizeRightIcon = true;
            this.randomUcnButton.BackColor = System.Drawing.Color.Transparent;
            this.randomUcnButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.randomUcnButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("randomUcnButton.BackgroundImage")));
            this.randomUcnButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomUcnButton.ButtonText = "Random UCN";
            this.randomUcnButton.ButtonTextMarginLeft = 0;
            this.randomUcnButton.ColorContrastOnClick = 45;
            this.randomUcnButton.ColorContrastOnHover = 45;
            this.randomUcnButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges9.BottomLeft = true;
            borderEdges9.BottomRight = true;
            borderEdges9.TopLeft = true;
            borderEdges9.TopRight = true;
            this.randomUcnButton.CustomizableEdges = borderEdges9;
            this.randomUcnButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.randomUcnButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.randomUcnButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.randomUcnButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.randomUcnButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.randomUcnButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.randomUcnButton.ForeColor = System.Drawing.Color.DimGray;
            this.randomUcnButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.randomUcnButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.randomUcnButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.randomUcnButton.IconMarginLeft = 11;
            this.randomUcnButton.IconPadding = 13;
            this.randomUcnButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.randomUcnButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.randomUcnButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.randomUcnButton.IconSize = 25;
            this.randomUcnButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.randomUcnButton.IdleBorderRadius = 1;
            this.randomUcnButton.IdleBorderThickness = 1;
            this.randomUcnButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.randomUcnButton.IdleIconLeftImage = null;
            this.randomUcnButton.IdleIconRightImage = null;
            this.randomUcnButton.IndicateFocus = true;
            this.randomUcnButton.Location = new System.Drawing.Point(671, 66);
            this.randomUcnButton.Name = "randomUcnButton";
            this.randomUcnButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.randomUcnButton.OnDisabledState.BorderRadius = 1;
            this.randomUcnButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomUcnButton.OnDisabledState.BorderThickness = 1;
            this.randomUcnButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.randomUcnButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.randomUcnButton.OnDisabledState.IconLeftImage = null;
            this.randomUcnButton.OnDisabledState.IconRightImage = null;
            this.randomUcnButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.randomUcnButton.onHoverState.BorderRadius = 1;
            this.randomUcnButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomUcnButton.onHoverState.BorderThickness = 1;
            this.randomUcnButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.randomUcnButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.randomUcnButton.onHoverState.IconLeftImage = null;
            this.randomUcnButton.onHoverState.IconRightImage = null;
            this.randomUcnButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.randomUcnButton.OnIdleState.BorderRadius = 1;
            this.randomUcnButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomUcnButton.OnIdleState.BorderThickness = 1;
            this.randomUcnButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.randomUcnButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.randomUcnButton.OnIdleState.IconLeftImage = null;
            this.randomUcnButton.OnIdleState.IconRightImage = null;
            this.randomUcnButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.randomUcnButton.OnPressedState.BorderRadius = 1;
            this.randomUcnButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.randomUcnButton.OnPressedState.BorderThickness = 1;
            this.randomUcnButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.randomUcnButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.randomUcnButton.OnPressedState.IconLeftImage = null;
            this.randomUcnButton.OnPressedState.IconRightImage = null;
            this.randomUcnButton.Size = new System.Drawing.Size(122, 25);
            this.randomUcnButton.TabIndex = 38;
            this.randomUcnButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.randomUcnButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.randomUcnButton.TextMarginLeft = 0;
            this.randomUcnButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.randomUcnButton.UseDefaultRadiusAndThickness = true;
            this.randomUcnButton.Click += new System.EventHandler(this.randomUcnButton_Click);
            // 
            // discountLabel
            // 
            this.discountLabel.AllowParentOverrides = false;
            this.discountLabel.AutoEllipsis = false;
            this.discountLabel.CursorType = null;
            this.discountLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.discountLabel.Location = new System.Drawing.Point(386, 290);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.discountLabel.Size = new System.Drawing.Size(64, 21);
            this.discountLabel.TabIndex = 34;
            this.discountLabel.Text = "Discount:";
            this.discountLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.discountLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // discountTxtBox
            // 
            this.discountTxtBox.AcceptsReturn = false;
            this.discountTxtBox.AcceptsTab = false;
            this.discountTxtBox.AnimationSpeed = 200;
            this.discountTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.discountTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.discountTxtBox.BackColor = System.Drawing.Color.White;
            this.discountTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("discountTxtBox.BackgroundImage")));
            this.discountTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.discountTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.discountTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.discountTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.discountTxtBox.BorderRadius = 1;
            this.discountTxtBox.BorderThickness = 1;
            this.discountTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.discountTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.discountTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.discountTxtBox.DefaultText = "";
            this.discountTxtBox.Enabled = false;
            this.discountTxtBox.FillColor = System.Drawing.Color.White;
            this.discountTxtBox.HideSelection = true;
            this.discountTxtBox.IconLeft = null;
            this.discountTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.discountTxtBox.IconPadding = 10;
            this.discountTxtBox.IconRight = null;
            this.discountTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.discountTxtBox.Lines = new string[0];
            this.discountTxtBox.Location = new System.Drawing.Point(463, 290);
            this.discountTxtBox.MaxLength = 32767;
            this.discountTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.discountTxtBox.Modified = false;
            this.discountTxtBox.Multiline = false;
            this.discountTxtBox.Name = "discountTxtBox";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.discountTxtBox.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.discountTxtBox.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.discountTxtBox.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.discountTxtBox.OnIdleState = stateProperties8;
            this.discountTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.discountTxtBox.PasswordChar = '\0';
            this.discountTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.discountTxtBox.PlaceholderText = "Discount";
            this.discountTxtBox.ReadOnly = false;
            this.discountTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.discountTxtBox.SelectedText = "";
            this.discountTxtBox.SelectionLength = 0;
            this.discountTxtBox.SelectionStart = 0;
            this.discountTxtBox.ShortcutsEnabled = true;
            this.discountTxtBox.Size = new System.Drawing.Size(280, 25);
            this.discountTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.discountTxtBox.TabIndex = 33;
            this.discountTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.discountTxtBox.TextMarginBottom = 0;
            this.discountTxtBox.TextMarginLeft = 3;
            this.discountTxtBox.TextMarginTop = 0;
            this.discountTxtBox.TextPlaceholder = "Discount";
            this.discountTxtBox.UseSystemPasswordChar = false;
            this.discountTxtBox.WordWrap = true;
            this.discountTxtBox.TextChange += new System.EventHandler(this.discountTxtBox_TextChange);
            // 
            // statusLabel
            // 
            this.statusLabel.AllowParentOverrides = false;
            this.statusLabel.AutoEllipsis = false;
            this.statusLabel.CursorType = null;
            this.statusLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.statusLabel.Location = new System.Drawing.Point(14, 323);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.statusLabel.Size = new System.Drawing.Size(46, 21);
            this.statusLabel.TabIndex = 30;
            this.statusLabel.Text = "Status:";
            this.statusLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.statusLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // statusDropdown
            // 
            this.statusDropdown.BackColor = System.Drawing.Color.Transparent;
            this.statusDropdown.BackgroundColor = System.Drawing.Color.White;
            this.statusDropdown.BorderColor = System.Drawing.Color.Silver;
            this.statusDropdown.BorderRadius = 1;
            this.statusDropdown.Color = System.Drawing.Color.Silver;
            this.statusDropdown.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.statusDropdown.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.statusDropdown.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.statusDropdown.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.statusDropdown.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.statusDropdown.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.statusDropdown.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.statusDropdown.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.statusDropdown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.statusDropdown.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.statusDropdown.FillDropDown = true;
            this.statusDropdown.FillIndicator = false;
            this.statusDropdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.statusDropdown.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.statusDropdown.ForeColor = System.Drawing.Color.Black;
            this.statusDropdown.FormattingEnabled = true;
            this.statusDropdown.Icon = null;
            this.statusDropdown.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.statusDropdown.IndicatorColor = System.Drawing.Color.Gray;
            this.statusDropdown.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.statusDropdown.ItemBackColor = System.Drawing.Color.White;
            this.statusDropdown.ItemBorderColor = System.Drawing.Color.White;
            this.statusDropdown.ItemForeColor = System.Drawing.Color.Black;
            this.statusDropdown.ItemHeight = 17;
            this.statusDropdown.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.statusDropdown.ItemHighLightForeColor = System.Drawing.Color.White;
            this.statusDropdown.Items.AddRange(new object[] {
            "Available",
            "Unavailable"});
            this.statusDropdown.ItemTopMargin = 3;
            this.statusDropdown.Location = new System.Drawing.Point(90, 323);
            this.statusDropdown.Name = "statusDropdown";
            this.statusDropdown.Size = new System.Drawing.Size(164, 23);
            this.statusDropdown.TabIndex = 29;
            this.statusDropdown.Text = null;
            this.statusDropdown.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.statusDropdown.TextLeftMargin = 5;
            // 
            // warrantyLabel
            // 
            this.warrantyLabel.AllowParentOverrides = false;
            this.warrantyLabel.AutoEllipsis = false;
            this.warrantyLabel.CursorType = null;
            this.warrantyLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.warrantyLabel.Location = new System.Drawing.Point(14, 275);
            this.warrantyLabel.Name = "warrantyLabel";
            this.warrantyLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.warrantyLabel.Size = new System.Drawing.Size(68, 21);
            this.warrantyLabel.TabIndex = 28;
            this.warrantyLabel.Text = "Warranty:";
            this.warrantyLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.warrantyLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // warrantyDropdown
            // 
            this.warrantyDropdown.BackColor = System.Drawing.Color.Transparent;
            this.warrantyDropdown.BackgroundColor = System.Drawing.Color.White;
            this.warrantyDropdown.BorderColor = System.Drawing.Color.Silver;
            this.warrantyDropdown.BorderRadius = 1;
            this.warrantyDropdown.Color = System.Drawing.Color.Silver;
            this.warrantyDropdown.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.warrantyDropdown.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.warrantyDropdown.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.warrantyDropdown.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.warrantyDropdown.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.warrantyDropdown.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.warrantyDropdown.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.warrantyDropdown.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.warrantyDropdown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.warrantyDropdown.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.warrantyDropdown.FillDropDown = true;
            this.warrantyDropdown.FillIndicator = false;
            this.warrantyDropdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.warrantyDropdown.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.warrantyDropdown.ForeColor = System.Drawing.Color.Black;
            this.warrantyDropdown.FormattingEnabled = true;
            this.warrantyDropdown.Icon = null;
            this.warrantyDropdown.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.warrantyDropdown.IndicatorColor = System.Drawing.Color.Gray;
            this.warrantyDropdown.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.warrantyDropdown.ItemBackColor = System.Drawing.Color.White;
            this.warrantyDropdown.ItemBorderColor = System.Drawing.Color.White;
            this.warrantyDropdown.ItemForeColor = System.Drawing.Color.Black;
            this.warrantyDropdown.ItemHeight = 17;
            this.warrantyDropdown.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.warrantyDropdown.ItemHighLightForeColor = System.Drawing.Color.White;
            this.warrantyDropdown.Items.AddRange(new object[] {
            "Available",
            "Unavailable"});
            this.warrantyDropdown.ItemTopMargin = 3;
            this.warrantyDropdown.Location = new System.Drawing.Point(90, 275);
            this.warrantyDropdown.Name = "warrantyDropdown";
            this.warrantyDropdown.Size = new System.Drawing.Size(164, 23);
            this.warrantyDropdown.TabIndex = 27;
            this.warrantyDropdown.Text = null;
            this.warrantyDropdown.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.warrantyDropdown.TextLeftMargin = 5;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuSeparator1.BackgroundImage")));
            this.bunifuSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuSeparator1.DashCap = Bunifu.UI.WinForms.BunifuSeparator.CapStyles.Flat;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.Silver;
            this.bunifuSeparator1.LineStyle = Bunifu.UI.WinForms.BunifuSeparator.LineStyles.Solid;
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(-1, 246);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Orientation = Bunifu.UI.WinForms.BunifuSeparator.LineOrientation.Horizontal;
            this.bunifuSeparator1.Size = new System.Drawing.Size(796, 21);
            this.bunifuSeparator1.TabIndex = 26;
            // 
            // currencyLabel
            // 
            this.currencyLabel.AllowParentOverrides = false;
            this.currencyLabel.AutoEllipsis = false;
            this.currencyLabel.CursorType = null;
            this.currencyLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.currencyLabel.Location = new System.Drawing.Point(489, 217);
            this.currencyLabel.Name = "currencyLabel";
            this.currencyLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.currencyLabel.Size = new System.Drawing.Size(66, 21);
            this.currencyLabel.TabIndex = 24;
            this.currencyLabel.Text = "Currency:";
            this.currencyLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.currencyLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // currencyDropdown
            // 
            this.currencyDropdown.BackColor = System.Drawing.Color.Transparent;
            this.currencyDropdown.BackgroundColor = System.Drawing.Color.White;
            this.currencyDropdown.BorderColor = System.Drawing.Color.Silver;
            this.currencyDropdown.BorderRadius = 1;
            this.currencyDropdown.Color = System.Drawing.Color.Silver;
            this.currencyDropdown.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.currencyDropdown.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.currencyDropdown.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.currencyDropdown.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.currencyDropdown.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.currencyDropdown.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.currencyDropdown.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.currencyDropdown.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.currencyDropdown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.currencyDropdown.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.currencyDropdown.FillDropDown = true;
            this.currencyDropdown.FillIndicator = false;
            this.currencyDropdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.currencyDropdown.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.currencyDropdown.ForeColor = System.Drawing.Color.Black;
            this.currencyDropdown.FormattingEnabled = true;
            this.currencyDropdown.Icon = null;
            this.currencyDropdown.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.currencyDropdown.IndicatorColor = System.Drawing.Color.Gray;
            this.currencyDropdown.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.currencyDropdown.ItemBackColor = System.Drawing.Color.White;
            this.currencyDropdown.ItemBorderColor = System.Drawing.Color.White;
            this.currencyDropdown.ItemForeColor = System.Drawing.Color.Black;
            this.currencyDropdown.ItemHeight = 17;
            this.currencyDropdown.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.currencyDropdown.ItemHighLightForeColor = System.Drawing.Color.White;
            this.currencyDropdown.Items.AddRange(new object[] {
            "ADP",
            "AED",
            "AFA",
            "AFN",
            "ALK",
            "ALL",
            "AMD",
            "ANG",
            "AOA",
            "AOK",
            "AON",
            "AOR",
            "ARA",
            "ARP",
            "ARS",
            "ARY",
            "ATS",
            "AUD",
            "AWG",
            "AYM",
            "AZM",
            "AZN",
            "BAD",
            "BAM",
            "BBD",
            "BDT",
            "BEC",
            "BEF",
            "BEL",
            "BGJ",
            "BGK",
            "BGL",
            "BGN",
            "BHD",
            "BIF",
            "BMD",
            "BND",
            "BOB",
            "BOP",
            "BOV",
            "BRB",
            "BRC",
            "BRE",
            "BRL",
            "BRN",
            "BRR",
            "BSD",
            "BTN",
            "BUK",
            "BWP",
            "BYB",
            "BYN",
            "BYR",
            "BZD",
            "CAD",
            "CDF",
            "CHC",
            "CHE",
            "CHF",
            "CHW",
            "CLF",
            "CLP",
            "CNY",
            "COP",
            "COU",
            "CRC",
            "CSD",
            "CSJ",
            "CSK",
            "CUC",
            "CUP",
            "CVE",
            "CYP",
            "CZK",
            "DDM",
            "DEM",
            "DJF",
            "DKK",
            "DOP",
            "DZD",
            "ECS",
            "ECV",
            "EEK",
            "EGP",
            "ERN",
            "ESA",
            "ESB",
            "ESP",
            "ETB",
            "EUR",
            "FIM",
            "FJD",
            "FKP",
            "FRF",
            "GBP",
            "GEK",
            "GEL",
            "GHC",
            "GHP",
            "GHS",
            "GIP",
            "GMD",
            "GNE",
            "GNF",
            "GNS",
            "GQE",
            "GRD",
            "GTQ",
            "GWE",
            "GWP",
            "GYD",
            "HKD",
            "HNL",
            "HRD",
            "HRK",
            "HTG",
            "HUF",
            "IDR",
            "IDR",
            "IEP",
            "ILP",
            "ILR",
            "ILS",
            "INR",
            "IQD",
            "IRR",
            "ISJ",
            "ISK",
            "ITL",
            "JMD",
            "JOD",
            "JPY",
            "KES",
            "KGS",
            "KHR",
            "KMF",
            "KPW",
            "KWD",
            "KYD",
            "KZT",
            "LAJ",
            "LAK",
            "LBP",
            "LKR",
            "LRD",
            "LSL",
            "LSM",
            "LTL",
            "LTT",
            "LUC",
            "LUF",
            "LUL",
            "LVL",
            "LVR",
            "LYD",
            "MAD",
            "MAD",
            "MDL",
            "MGA",
            "MGF",
            "MKD",
            "MLF",
            "MMK",
            "MNT",
            "MOP",
            "MRO",
            "MTL",
            "MTP",
            "MUR",
            "MVQ",
            "MVR",
            "MWK",
            "MXN",
            "MXP",
            "MXV",
            "MYR",
            "MZE",
            "MZM",
            "NAD",
            "NGN",
            "NIC",
            "NIO",
            "NLG",
            "NOK",
            "NPR",
            "NZD",
            "OMR",
            "PAB",
            "PEH",
            "PEI",
            "PEN",
            "PES",
            "PGK",
            "PHP",
            "PKR",
            "PLN",
            "PLZ",
            "PTE",
            "PYG",
            "QAR",
            "RHD",
            "ROK",
            "ROL",
            "RON",
            "RSD",
            "RUB",
            "RUR",
            "RWF",
            "SAR",
            "SBD",
            "SCR",
            "SDD",
            "SDG",
            "SDG",
            "SDP",
            "SEK",
            "SGD",
            "SHP",
            "SIT",
            "SKK",
            "SLL",
            "SOS",
            "SOM",
            "SRD",
            "SRG",
            "SSP",
            "STD",
            "SUR",
            "SVC",
            "SYP",
            "SZL",
            "THB",
            "TJR",
            "TJS",
            "TMM",
            "TMT",
            "TND",
            "TOP",
            "TPE",
            "TRL",
            "TRY",
            "TRY",
            "TTD",
            "TWD",
            "TZS",
            "UAH",
            "UAK",
            "UGS",
            "UGW",
            "UGX",
            "USD",
            "USN",
            "USS",
            "UYI",
            "UYN",
            "UYP",
            "UYU",
            "UZS",
            "VEB",
            "VEF",
            "VEF",
            "VEF",
            "VNC",
            "VND",
            "VUV",
            "WST",
            "XAF",
            "XAG",
            "XAU",
            "XBA",
            "XBB",
            "XBC",
            "XBD",
            "XCD",
            "XDR",
            "XEU",
            "XFO",
            "XFU",
            "XOF",
            "XOF",
            "XPD",
            "XPF",
            "XPT",
            "XRE",
            "XSU",
            "XTS",
            "XUA",
            "XXX",
            "YDD",
            "YER",
            "YUD",
            "YUM",
            "YUN",
            "ZAL",
            "ZAL",
            "ZAR",
            "ZMK",
            "ZMW",
            "ZRN",
            "ZRZ",
            "ZWC",
            "ZWD",
            "ZWL",
            "ZWN",
            "ZWR"});
            this.currencyDropdown.ItemTopMargin = 3;
            this.currencyDropdown.Location = new System.Drawing.Point(561, 217);
            this.currencyDropdown.Name = "currencyDropdown";
            this.currencyDropdown.Size = new System.Drawing.Size(116, 23);
            this.currencyDropdown.TabIndex = 23;
            this.currencyDropdown.Text = null;
            this.currencyDropdown.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.currencyDropdown.TextLeftMargin = 5;
            // 
            // firstCostTxtBox
            // 
            this.firstCostTxtBox.AcceptsReturn = false;
            this.firstCostTxtBox.AcceptsTab = false;
            this.firstCostTxtBox.AnimationSpeed = 200;
            this.firstCostTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.firstCostTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.firstCostTxtBox.BackColor = System.Drawing.Color.White;
            this.firstCostTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("firstCostTxtBox.BackgroundImage")));
            this.firstCostTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.firstCostTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.firstCostTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.firstCostTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.firstCostTxtBox.BorderRadius = 1;
            this.firstCostTxtBox.BorderThickness = 1;
            this.firstCostTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.firstCostTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.firstCostTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.firstCostTxtBox.DefaultText = "";
            this.firstCostTxtBox.Enabled = false;
            this.firstCostTxtBox.FillColor = System.Drawing.Color.White;
            this.firstCostTxtBox.HideSelection = true;
            this.firstCostTxtBox.IconLeft = null;
            this.firstCostTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.firstCostTxtBox.IconPadding = 10;
            this.firstCostTxtBox.IconRight = null;
            this.firstCostTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.firstCostTxtBox.Lines = new string[0];
            this.firstCostTxtBox.Location = new System.Drawing.Point(314, 217);
            this.firstCostTxtBox.MaxLength = 32767;
            this.firstCostTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.firstCostTxtBox.Modified = false;
            this.firstCostTxtBox.Multiline = false;
            this.firstCostTxtBox.Name = "firstCostTxtBox";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.firstCostTxtBox.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.firstCostTxtBox.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.firstCostTxtBox.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.firstCostTxtBox.OnIdleState = stateProperties12;
            this.firstCostTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.firstCostTxtBox.PasswordChar = '\0';
            this.firstCostTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.firstCostTxtBox.PlaceholderText = "Cost";
            this.firstCostTxtBox.ReadOnly = false;
            this.firstCostTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.firstCostTxtBox.SelectedText = "";
            this.firstCostTxtBox.SelectionLength = 0;
            this.firstCostTxtBox.SelectionStart = 0;
            this.firstCostTxtBox.ShortcutsEnabled = true;
            this.firstCostTxtBox.Size = new System.Drawing.Size(156, 25);
            this.firstCostTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.firstCostTxtBox.TabIndex = 16;
            this.firstCostTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.firstCostTxtBox.TextMarginBottom = 0;
            this.firstCostTxtBox.TextMarginLeft = 3;
            this.firstCostTxtBox.TextMarginTop = 0;
            this.firstCostTxtBox.TextPlaceholder = "Cost";
            this.firstCostTxtBox.UseSystemPasswordChar = false;
            this.firstCostTxtBox.WordWrap = true;
            this.firstCostTxtBox.TextChange += new System.EventHandler(this.costTxtBox_TextChange);
            // 
            // costLabel
            // 
            this.costLabel.AllowParentOverrides = false;
            this.costLabel.AutoEllipsis = false;
            this.costLabel.CursorType = null;
            this.costLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.costLabel.Location = new System.Drawing.Point(265, 219);
            this.costLabel.Name = "costLabel";
            this.costLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.costLabel.Size = new System.Drawing.Size(34, 21);
            this.costLabel.TabIndex = 15;
            this.costLabel.Text = "Cost:";
            this.costLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.costLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // amountTxtBox
            // 
            this.amountTxtBox.AcceptsReturn = false;
            this.amountTxtBox.AcceptsTab = false;
            this.amountTxtBox.AnimationSpeed = 200;
            this.amountTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.amountTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.amountTxtBox.BackColor = System.Drawing.Color.White;
            this.amountTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("amountTxtBox.BackgroundImage")));
            this.amountTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.amountTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.amountTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.amountTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.amountTxtBox.BorderRadius = 1;
            this.amountTxtBox.BorderThickness = 1;
            this.amountTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.amountTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.amountTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.amountTxtBox.DefaultText = "";
            this.amountTxtBox.FillColor = System.Drawing.Color.White;
            this.amountTxtBox.HideSelection = true;
            this.amountTxtBox.IconLeft = null;
            this.amountTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.amountTxtBox.IconPadding = 10;
            this.amountTxtBox.IconRight = null;
            this.amountTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.amountTxtBox.Lines = new string[0];
            this.amountTxtBox.Location = new System.Drawing.Point(90, 217);
            this.amountTxtBox.MaxLength = 32767;
            this.amountTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.amountTxtBox.Modified = false;
            this.amountTxtBox.Multiline = false;
            this.amountTxtBox.Name = "amountTxtBox";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.amountTxtBox.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.amountTxtBox.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.amountTxtBox.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.amountTxtBox.OnIdleState = stateProperties16;
            this.amountTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.amountTxtBox.PasswordChar = '\0';
            this.amountTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.amountTxtBox.PlaceholderText = "Enter amount";
            this.amountTxtBox.ReadOnly = false;
            this.amountTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.amountTxtBox.SelectedText = "";
            this.amountTxtBox.SelectionLength = 0;
            this.amountTxtBox.SelectionStart = 0;
            this.amountTxtBox.ShortcutsEnabled = true;
            this.amountTxtBox.Size = new System.Drawing.Size(164, 25);
            this.amountTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.amountTxtBox.TabIndex = 14;
            this.amountTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.amountTxtBox.TextMarginBottom = 0;
            this.amountTxtBox.TextMarginLeft = 3;
            this.amountTxtBox.TextMarginTop = 0;
            this.amountTxtBox.TextPlaceholder = "Enter amount";
            this.amountTxtBox.UseSystemPasswordChar = false;
            this.amountTxtBox.WordWrap = true;
            this.amountTxtBox.TextChange += new System.EventHandler(this.amountTxtBox_TextChange);
            // 
            // amountLabel
            // 
            this.amountLabel.AllowParentOverrides = false;
            this.amountLabel.AutoEllipsis = false;
            this.amountLabel.CursorType = null;
            this.amountLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.amountLabel.Location = new System.Drawing.Point(25, 217);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.amountLabel.Size = new System.Drawing.Size(59, 21);
            this.amountLabel.TabIndex = 13;
            this.amountLabel.Text = "Amount:";
            this.amountLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.amountLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // separator
            // 
            this.separator.BackColor = System.Drawing.Color.Transparent;
            this.separator.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("separator.BackgroundImage")));
            this.separator.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.separator.DashCap = Bunifu.UI.WinForms.BunifuSeparator.CapStyles.Flat;
            this.separator.LineColor = System.Drawing.Color.Silver;
            this.separator.LineStyle = Bunifu.UI.WinForms.BunifuSeparator.LineStyles.Solid;
            this.separator.LineThickness = 1;
            this.separator.Location = new System.Drawing.Point(-4, 190);
            this.separator.Name = "separator";
            this.separator.Orientation = Bunifu.UI.WinForms.BunifuSeparator.LineOrientation.Horizontal;
            this.separator.Size = new System.Drawing.Size(796, 21);
            this.separator.TabIndex = 12;
            // 
            // countryDropdown
            // 
            this.countryDropdown.AccessibleDescription = "Choose your country";
            this.countryDropdown.BackColor = System.Drawing.Color.Transparent;
            this.countryDropdown.BackgroundColor = System.Drawing.Color.White;
            this.countryDropdown.BorderColor = System.Drawing.Color.Silver;
            this.countryDropdown.BorderRadius = 1;
            this.countryDropdown.Color = System.Drawing.Color.Silver;
            this.countryDropdown.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.countryDropdown.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.countryDropdown.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.countryDropdown.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.countryDropdown.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.countryDropdown.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.countryDropdown.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.countryDropdown.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.countryDropdown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.countryDropdown.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.countryDropdown.FillDropDown = true;
            this.countryDropdown.FillIndicator = false;
            this.countryDropdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.countryDropdown.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.countryDropdown.ForeColor = System.Drawing.Color.Black;
            this.countryDropdown.FormattingEnabled = true;
            this.countryDropdown.Icon = null;
            this.countryDropdown.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.countryDropdown.IndicatorColor = System.Drawing.Color.Gray;
            this.countryDropdown.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.countryDropdown.ItemBackColor = System.Drawing.Color.White;
            this.countryDropdown.ItemBorderColor = System.Drawing.Color.White;
            this.countryDropdown.ItemForeColor = System.Drawing.Color.Black;
            this.countryDropdown.ItemHeight = 18;
            this.countryDropdown.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.countryDropdown.ItemHighLightForeColor = System.Drawing.Color.White;
            this.countryDropdown.Items.AddRange(new object[] {
            "Afghanistan",
            "Albania",
            "Algeria",
            "Andorra",
            "Angola",
            "Antigua & Deps",
            "Argentina",
            "Armenia",
            "Australia",
            "Austria",
            "Azerbaijan",
            "Bahamas",
            "Bahrain",
            "Bangladesh",
            "Barbados",
            "Belarus",
            "Belgium",
            "Belize",
            "Benin",
            "Bhutan",
            "Bolivia",
            "Bosnia Herzegovina",
            "Botswana",
            "Brazil",
            "Brunei",
            "Bulgaria",
            "Burkina",
            "Burundi",
            "Cambodia",
            "Cameroon",
            "Canada",
            "Cape Verde",
            "Central African Rep",
            "Chad",
            "Chile",
            "China",
            "Colombia",
            "Comoros",
            "Congo",
            "Congo {Democratic Rep}",
            "Costa Rica",
            "Croatia",
            "Cuba",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Djibouti",
            "Dominica",
            "Dominican Republic",
            "East Timor",
            "Ecuador",
            "Egypt",
            "El Salvador",
            "Equatorial Guinea",
            "Eritrea",
            "Estonia",
            "Ethiopia",
            "Fiji",
            "Finland",
            "France",
            "Gabon",
            "Gambia",
            "Georgia",
            "Germany",
            "Ghana",
            "Greece",
            "Grenada",
            "Guatemala",
            "Guinea",
            "Guinea-Bissau",
            "Guyana",
            "Haiti",
            "Honduras",
            "Hungary",
            "Iceland",
            "India",
            "Indonesia",
            "Iran",
            "Iraq",
            "Ireland {Republic}",
            "Israel",
            "Italy",
            "Ivory Coast",
            "Jamaica",
            "Japan",
            "Jordan",
            "Kazakhstan",
            "Kenya",
            "Kiribati",
            "Korea North",
            "Korea South",
            "Kosovo",
            "Kuwait",
            "Kyrgyzstan",
            "Laos",
            "Latvia",
            "Lebanon",
            "Lesotho",
            "Liberia",
            "Libya",
            "Liechtenstein",
            "Lithuania",
            "Luxembourg",
            "Macedonia",
            "Madagascar",
            "Malawi",
            "Malaysia",
            "Maldives",
            "Mali",
            "Malta",
            "Marshall Islands",
            "Mauritania",
            "Mauritius",
            "Mexico",
            "Micronesia",
            "Moldova",
            "Monaco",
            "Mongolia",
            "Montenegro",
            "Morocco",
            "Mozambique",
            "Myanmar, {Burma}",
            "Namibia",
            "Nauru",
            "Nepal",
            "Netherlands",
            "New Zealand",
            "Nicaragua",
            "Niger",
            "Nigeria",
            "Norway",
            "Oman",
            "Pakistan",
            "Palau",
            "Panama",
            "Papua New Guinea",
            "Paraguay",
            "Peru",
            "Philippines",
            "Poland",
            "Portugal",
            "Qatar",
            "Romania",
            "Russian Federation",
            "Rwanda",
            "St Kitts & Nevis",
            "St Lucia",
            "Saint Vincent & the Grenadines",
            "Samoa",
            "San Marino",
            "Sao Tome & Principe",
            "Saudi Arabia",
            "Senegal",
            "Serbia",
            "Seychelles",
            "Sierra Leone",
            "Singapore",
            "Slovakia",
            "Slovenia",
            "Solomon Islands",
            "Somalia",
            "South Africa",
            "South Sudan",
            "Spain",
            "Sri Lanka",
            "Sudan",
            "Suriname",
            "Swaziland",
            "Sweden",
            "Switzerland",
            "Syria",
            "Taiwan",
            "Tajikistan",
            "Tanzania",
            "Thailand",
            "Togo",
            "Tonga",
            "Trinidad & Tobago",
            "Tunisia",
            "Turkey",
            "Turkmenistan",
            "Tuvalu",
            "Uganda",
            "Ukraine",
            "United Arab Emirates",
            "United Kingdom",
            "United States",
            "Uruguay",
            "Uzbekistan",
            "Vanuatu",
            "Vatican City",
            "Venezuela",
            "Vietnam",
            "Yemen",
            "Zambia",
            "Zimbabwe"});
            this.countryDropdown.ItemTopMargin = 3;
            this.countryDropdown.Location = new System.Drawing.Point(90, 149);
            this.countryDropdown.Name = "countryDropdown";
            this.countryDropdown.Size = new System.Drawing.Size(260, 24);
            this.countryDropdown.TabIndex = 11;
            this.countryDropdown.Text = null;
            this.countryDropdown.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.countryDropdown.TextLeftMargin = 5;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bunifuLabel4.Location = new System.Drawing.Point(25, 149);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(59, 21);
            this.bunifuLabel4.TabIndex = 10;
            this.bunifuLabel4.Text = "Country:";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // companyLabel
            // 
            this.companyLabel.AllowParentOverrides = false;
            this.companyLabel.AutoEllipsis = false;
            this.companyLabel.CursorType = null;
            this.companyLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.companyLabel.Location = new System.Drawing.Point(14, 109);
            this.companyLabel.Name = "companyLabel";
            this.companyLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.companyLabel.Size = new System.Drawing.Size(70, 21);
            this.companyLabel.TabIndex = 8;
            this.companyLabel.Text = "Company:";
            this.companyLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.companyLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // ucnTxtBox
            // 
            this.ucnTxtBox.AcceptsReturn = false;
            this.ucnTxtBox.AcceptsTab = false;
            this.ucnTxtBox.AnimationSpeed = 200;
            this.ucnTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.ucnTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.ucnTxtBox.BackColor = System.Drawing.Color.White;
            this.ucnTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ucnTxtBox.BackgroundImage")));
            this.ucnTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.ucnTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ucnTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.ucnTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.ucnTxtBox.BorderRadius = 1;
            this.ucnTxtBox.BorderThickness = 1;
            this.ucnTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.ucnTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ucnTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.ucnTxtBox.DefaultText = "";
            this.ucnTxtBox.FillColor = System.Drawing.Color.White;
            this.ucnTxtBox.HideSelection = true;
            this.ucnTxtBox.IconLeft = null;
            this.ucnTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.ucnTxtBox.IconPadding = 10;
            this.ucnTxtBox.IconRight = null;
            this.ucnTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.ucnTxtBox.Lines = new string[0];
            this.ucnTxtBox.Location = new System.Drawing.Point(456, 66);
            this.ucnTxtBox.MaxLength = 32767;
            this.ucnTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.ucnTxtBox.Modified = false;
            this.ucnTxtBox.Multiline = false;
            this.ucnTxtBox.Name = "ucnTxtBox";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ucnTxtBox.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.ucnTxtBox.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ucnTxtBox.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ucnTxtBox.OnIdleState = stateProperties20;
            this.ucnTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.ucnTxtBox.PasswordChar = '\0';
            this.ucnTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.ucnTxtBox.PlaceholderText = "Enter ucn";
            this.ucnTxtBox.ReadOnly = false;
            this.ucnTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ucnTxtBox.SelectedText = "";
            this.ucnTxtBox.SelectionLength = 0;
            this.ucnTxtBox.SelectionStart = 0;
            this.ucnTxtBox.ShortcutsEnabled = true;
            this.ucnTxtBox.Size = new System.Drawing.Size(209, 25);
            this.ucnTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.ucnTxtBox.TabIndex = 6;
            this.ucnTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ucnTxtBox.TextMarginBottom = 0;
            this.ucnTxtBox.TextMarginLeft = 3;
            this.ucnTxtBox.TextMarginTop = 0;
            this.ucnTxtBox.TextPlaceholder = "Enter ucn";
            this.ucnTxtBox.UseSystemPasswordChar = false;
            this.ucnTxtBox.WordWrap = true;
            this.ucnTxtBox.TextChange += new System.EventHandler(this.ucnTxtBox_TextChange);
            // 
            // ucnLabel
            // 
            this.ucnLabel.AccessibleDescription = "Уникальный номер контракта";
            this.ucnLabel.AllowParentOverrides = false;
            this.ucnLabel.AutoEllipsis = false;
            this.ucnLabel.CursorType = null;
            this.ucnLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ucnLabel.Location = new System.Drawing.Point(414, 66);
            this.ucnLabel.Name = "ucnLabel";
            this.ucnLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ucnLabel.Size = new System.Drawing.Size(36, 21);
            this.ucnLabel.TabIndex = 5;
            this.ucnLabel.Text = "UCN:";
            this.ucnLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.ucnLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // codeLabel
            // 
            this.codeLabel.AllowParentOverrides = false;
            this.codeLabel.AutoEllipsis = false;
            this.codeLabel.CursorType = null;
            this.codeLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.codeLabel.Location = new System.Drawing.Point(39, 66);
            this.codeLabel.Name = "codeLabel";
            this.codeLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.codeLabel.Size = new System.Drawing.Size(39, 21);
            this.codeLabel.TabIndex = 3;
            this.codeLabel.Text = "Code:";
            this.codeLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.codeLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // codeTxtBox
            // 
            this.codeTxtBox.AcceptsReturn = false;
            this.codeTxtBox.AcceptsTab = false;
            this.codeTxtBox.AnimationSpeed = 200;
            this.codeTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.codeTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.codeTxtBox.BackColor = System.Drawing.Color.White;
            this.codeTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("codeTxtBox.BackgroundImage")));
            this.codeTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.codeTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.codeTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.codeTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.codeTxtBox.BorderRadius = 1;
            this.codeTxtBox.BorderThickness = 1;
            this.codeTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.codeTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.codeTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.codeTxtBox.DefaultText = "";
            this.codeTxtBox.FillColor = System.Drawing.Color.White;
            this.codeTxtBox.HideSelection = true;
            this.codeTxtBox.IconLeft = null;
            this.codeTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.codeTxtBox.IconPadding = 10;
            this.codeTxtBox.IconRight = null;
            this.codeTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.codeTxtBox.Lines = new string[0];
            this.codeTxtBox.Location = new System.Drawing.Point(90, 66);
            this.codeTxtBox.MaxLength = 32767;
            this.codeTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.codeTxtBox.Modified = false;
            this.codeTxtBox.Multiline = false;
            this.codeTxtBox.Name = "codeTxtBox";
            stateProperties21.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.codeTxtBox.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.codeTxtBox.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.codeTxtBox.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.codeTxtBox.OnIdleState = stateProperties24;
            this.codeTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.codeTxtBox.PasswordChar = '\0';
            this.codeTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.codeTxtBox.PlaceholderText = "Enter code";
            this.codeTxtBox.ReadOnly = false;
            this.codeTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.codeTxtBox.SelectedText = "";
            this.codeTxtBox.SelectionLength = 0;
            this.codeTxtBox.SelectionStart = 0;
            this.codeTxtBox.ShortcutsEnabled = true;
            this.codeTxtBox.Size = new System.Drawing.Size(229, 25);
            this.codeTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.codeTxtBox.TabIndex = 2;
            this.codeTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.codeTxtBox.TextMarginBottom = 0;
            this.codeTxtBox.TextMarginLeft = 3;
            this.codeTxtBox.TextMarginTop = 0;
            this.codeTxtBox.TextPlaceholder = "Enter code";
            this.codeTxtBox.UseSystemPasswordChar = false;
            this.codeTxtBox.WordWrap = true;
            this.codeTxtBox.TextChange += new System.EventHandler(this.codeTxtBox_TextChange);
            // 
            // nameLabel
            // 
            this.nameLabel.AllowParentOverrides = false;
            this.nameLabel.AutoEllipsis = false;
            this.nameLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.nameLabel.CursorType = System.Windows.Forms.Cursors.Default;
            this.nameLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.nameLabel.Location = new System.Drawing.Point(39, 25);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nameLabel.Size = new System.Drawing.Size(45, 21);
            this.nameLabel.TabIndex = 1;
            this.nameLabel.Text = "Name:";
            this.nameLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.nameLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // nameTxtBox
            // 
            this.nameTxtBox.AcceptsReturn = false;
            this.nameTxtBox.AcceptsTab = false;
            this.nameTxtBox.AnimationSpeed = 200;
            this.nameTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.nameTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.nameTxtBox.BackColor = System.Drawing.Color.White;
            this.nameTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("nameTxtBox.BackgroundImage")));
            this.nameTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.nameTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.nameTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.nameTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.nameTxtBox.BorderRadius = 1;
            this.nameTxtBox.BorderThickness = 1;
            this.nameTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.nameTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.nameTxtBox.DefaultText = "";
            this.nameTxtBox.FillColor = System.Drawing.Color.White;
            this.nameTxtBox.HideSelection = true;
            this.nameTxtBox.IconLeft = null;
            this.nameTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxtBox.IconPadding = 10;
            this.nameTxtBox.IconRight = null;
            this.nameTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxtBox.Lines = new string[0];
            this.nameTxtBox.Location = new System.Drawing.Point(90, 25);
            this.nameTxtBox.MaxLength = 32767;
            this.nameTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.nameTxtBox.Modified = false;
            this.nameTxtBox.Multiline = false;
            this.nameTxtBox.Name = "nameTxtBox";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.nameTxtBox.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.nameTxtBox.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.nameTxtBox.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.nameTxtBox.OnIdleState = stateProperties28;
            this.nameTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.nameTxtBox.PasswordChar = '\0';
            this.nameTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.nameTxtBox.PlaceholderText = "Enter name";
            this.nameTxtBox.ReadOnly = false;
            this.nameTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.nameTxtBox.SelectedText = "";
            this.nameTxtBox.SelectionLength = 0;
            this.nameTxtBox.SelectionStart = 0;
            this.nameTxtBox.ShortcutsEnabled = true;
            this.nameTxtBox.Size = new System.Drawing.Size(436, 25);
            this.nameTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.nameTxtBox.TabIndex = 0;
            this.nameTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.nameTxtBox.TextMarginBottom = 0;
            this.nameTxtBox.TextMarginLeft = 3;
            this.nameTxtBox.TextMarginTop = 0;
            this.nameTxtBox.TextPlaceholder = "Enter name";
            this.nameTxtBox.UseSystemPasswordChar = false;
            this.nameTxtBox.WordWrap = true;
            this.nameTxtBox.TextChange += new System.EventHandler(this.nameTxtBox_TextChange);
            // 
            // extraFunc
            // 
            this.extraFunc.Controls.Add(this.descriptionTxtBox);
            this.extraFunc.Controls.Add(this.descriptionLabel);
            this.extraFunc.Controls.Add(this.editImageButton);
            this.extraFunc.Controls.Add(this.imageLabel);
            this.extraFunc.Controls.Add(this.imageFileBox);
            this.extraFunc.Location = new System.Drawing.Point(4, 4);
            this.extraFunc.Name = "extraFunc";
            this.extraFunc.Padding = new System.Windows.Forms.Padding(3);
            this.extraFunc.Size = new System.Drawing.Size(808, 402);
            this.extraFunc.TabIndex = 1;
            this.extraFunc.Text = "Extra Function";
            this.extraFunc.ToolTipText = "Дополнительные свойства";
            this.extraFunc.UseVisualStyleBackColor = true;
            // 
            // descriptionTxtBox
            // 
            this.descriptionTxtBox.Location = new System.Drawing.Point(85, 249);
            this.descriptionTxtBox.Name = "descriptionTxtBox";
            this.descriptionTxtBox.Size = new System.Drawing.Size(621, 139);
            this.descriptionTxtBox.TabIndex = 43;
            this.descriptionTxtBox.Text = "";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AllowParentOverrides = false;
            this.descriptionLabel.AutoEllipsis = false;
            this.descriptionLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.descriptionLabel.CursorType = System.Windows.Forms.Cursors.Default;
            this.descriptionLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descriptionLabel.Location = new System.Drawing.Point(85, 215);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.descriptionLabel.Size = new System.Drawing.Size(108, 28);
            this.descriptionLabel.TabIndex = 42;
            this.descriptionLabel.Text = "Description:";
            this.descriptionLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.descriptionLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // editImageButton
            // 
            this.editImageButton.AllowAnimations = true;
            this.editImageButton.AllowMouseEffects = true;
            this.editImageButton.AllowToggling = true;
            this.editImageButton.AnimationSpeed = 200;
            this.editImageButton.AutoGenerateColors = false;
            this.editImageButton.AutoRoundBorders = false;
            this.editImageButton.AutoSizeLeftIcon = true;
            this.editImageButton.AutoSizeRightIcon = true;
            this.editImageButton.BackColor = System.Drawing.Color.Transparent;
            this.editImageButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.editImageButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("editImageButton.BackgroundImage")));
            this.editImageButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.editImageButton.ButtonText = "Edit Image";
            this.editImageButton.ButtonTextMarginLeft = 0;
            this.editImageButton.ColorContrastOnClick = 45;
            this.editImageButton.ColorContrastOnHover = 45;
            this.editImageButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.editImageButton.CustomizableEdges = borderEdges10;
            this.editImageButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.editImageButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.editImageButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.editImageButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.editImageButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.editImageButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editImageButton.ForeColor = System.Drawing.Color.DimGray;
            this.editImageButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.editImageButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.editImageButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.editImageButton.IconMarginLeft = 11;
            this.editImageButton.IconPadding = 13;
            this.editImageButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.editImageButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.editImageButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.editImageButton.IconSize = 25;
            this.editImageButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.editImageButton.IdleBorderRadius = 1;
            this.editImageButton.IdleBorderThickness = 1;
            this.editImageButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.editImageButton.IdleIconLeftImage = null;
            this.editImageButton.IdleIconRightImage = null;
            this.editImageButton.IndicateFocus = true;
            this.editImageButton.Location = new System.Drawing.Point(584, 106);
            this.editImageButton.Name = "editImageButton";
            this.editImageButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.editImageButton.OnDisabledState.BorderRadius = 1;
            this.editImageButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.editImageButton.OnDisabledState.BorderThickness = 1;
            this.editImageButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.editImageButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.editImageButton.OnDisabledState.IconLeftImage = null;
            this.editImageButton.OnDisabledState.IconRightImage = null;
            this.editImageButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.editImageButton.onHoverState.BorderRadius = 1;
            this.editImageButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.editImageButton.onHoverState.BorderThickness = 1;
            this.editImageButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.editImageButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.editImageButton.onHoverState.IconLeftImage = null;
            this.editImageButton.onHoverState.IconRightImage = null;
            this.editImageButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.editImageButton.OnIdleState.BorderRadius = 1;
            this.editImageButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.editImageButton.OnIdleState.BorderThickness = 1;
            this.editImageButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.editImageButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.editImageButton.OnIdleState.IconLeftImage = null;
            this.editImageButton.OnIdleState.IconRightImage = null;
            this.editImageButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.editImageButton.OnPressedState.BorderRadius = 1;
            this.editImageButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.editImageButton.OnPressedState.BorderThickness = 1;
            this.editImageButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.editImageButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.editImageButton.OnPressedState.IconLeftImage = null;
            this.editImageButton.OnPressedState.IconRightImage = null;
            this.editImageButton.Size = new System.Drawing.Size(122, 34);
            this.editImageButton.TabIndex = 41;
            this.editImageButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.editImageButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.editImageButton.TextMarginLeft = 0;
            this.editImageButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.editImageButton.UseDefaultRadiusAndThickness = true;
            this.editImageButton.Click += new System.EventHandler(this.editImageButton_Click);
            // 
            // imageLabel
            // 
            this.imageLabel.AllowParentOverrides = false;
            this.imageLabel.AutoEllipsis = false;
            this.imageLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.imageLabel.CursorType = System.Windows.Forms.Cursors.Default;
            this.imageLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.imageLabel.Location = new System.Drawing.Point(85, 95);
            this.imageLabel.Name = "imageLabel";
            this.imageLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.imageLabel.Size = new System.Drawing.Size(102, 45);
            this.imageLabel.TabIndex = 1;
            this.imageLabel.Text = "Image:";
            this.imageLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.imageLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // imageFileBox
            // 
            this.imageFileBox.AllowFocused = false;
            this.imageFileBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.imageFileBox.AutoSizeHeight = true;
            this.imageFileBox.BorderRadius = 82;
            this.imageFileBox.Image = global::Warehouse.Properties.Resources.iconProduc;
            this.imageFileBox.IsCircle = true;
            this.imageFileBox.Location = new System.Drawing.Point(314, 31);
            this.imageFileBox.Name = "imageFileBox";
            this.imageFileBox.Size = new System.Drawing.Size(165, 165);
            this.imageFileBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageFileBox.TabIndex = 0;
            this.imageFileBox.TabStop = false;
            this.imageFileBox.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            // 
            // panelSettings
            // 
            this.panelSettings.BackColor = System.Drawing.Color.Transparent;
            this.panelSettings.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.panelSettings.BorderRadius = 1;
            this.panelSettings.BorderThickness = 1;
            this.panelSettings.Controls.Add(this.controlPage);
            this.panelSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSettings.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.panelSettings.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.panelSettings.Location = new System.Drawing.Point(0, 56);
            this.panelSettings.Name = "panelSettings";
            this.panelSettings.PanelColor = System.Drawing.Color.WhiteSmoke;
            this.panelSettings.PanelColor2 = System.Drawing.Color.WhiteSmoke;
            this.panelSettings.ShadowColor = System.Drawing.Color.DarkGray;
            this.panelSettings.ShadowDept = 2;
            this.panelSettings.ShadowDepth = 5;
            this.panelSettings.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.panelSettings.ShadowTopLeftVisible = false;
            this.panelSettings.Size = new System.Drawing.Size(816, 428);
            this.panelSettings.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.panelSettings.TabIndex = 2;
            // 
            // secondTopPanel
            // 
            this.secondTopPanel.BackgroundColor = System.Drawing.Color.Transparent;
            this.secondTopPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("secondTopPanel.BackgroundImage")));
            this.secondTopPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.secondTopPanel.BorderColor = System.Drawing.Color.Transparent;
            this.secondTopPanel.BorderRadius = 3;
            this.secondTopPanel.BorderThickness = 1;
            this.secondTopPanel.Controls.Add(this.extraFuncButton);
            this.secondTopPanel.Controls.Add(this.mainFuncButton);
            this.secondTopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.secondTopPanel.Location = new System.Drawing.Point(0, 27);
            this.secondTopPanel.Name = "secondTopPanel";
            this.secondTopPanel.ShowBorders = true;
            this.secondTopPanel.Size = new System.Drawing.Size(816, 29);
            this.secondTopPanel.TabIndex = 3;
            // 
            // extraFuncButton
            // 
            this.extraFuncButton.AllowAnimations = true;
            this.extraFuncButton.AllowMouseEffects = true;
            this.extraFuncButton.AllowToggling = true;
            this.extraFuncButton.AnimationSpeed = 200;
            this.extraFuncButton.AutoGenerateColors = false;
            this.extraFuncButton.AutoRoundBorders = false;
            this.extraFuncButton.AutoSizeLeftIcon = true;
            this.extraFuncButton.AutoSizeRightIcon = true;
            this.extraFuncButton.BackColor = System.Drawing.Color.Transparent;
            this.extraFuncButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.extraFuncButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("extraFuncButton.BackgroundImage")));
            this.extraFuncButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.extraFuncButton.ButtonText = "Extra Function";
            this.extraFuncButton.ButtonTextMarginLeft = 0;
            this.extraFuncButton.ColorContrastOnClick = 45;
            this.extraFuncButton.ColorContrastOnHover = 45;
            this.extraFuncButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.extraFuncButton.CustomizableEdges = borderEdges11;
            this.extraFuncButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.extraFuncButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.extraFuncButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.extraFuncButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.extraFuncButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.extraFuncButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.extraFuncButton.ForeColor = System.Drawing.Color.DimGray;
            this.extraFuncButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.extraFuncButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.extraFuncButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.extraFuncButton.IconMarginLeft = 11;
            this.extraFuncButton.IconPadding = 13;
            this.extraFuncButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.extraFuncButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.extraFuncButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.extraFuncButton.IconSize = 25;
            this.extraFuncButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.extraFuncButton.IdleBorderRadius = 1;
            this.extraFuncButton.IdleBorderThickness = 1;
            this.extraFuncButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.extraFuncButton.IdleIconLeftImage = null;
            this.extraFuncButton.IdleIconRightImage = null;
            this.extraFuncButton.IndicateFocus = true;
            this.extraFuncButton.Location = new System.Drawing.Point(153, 6);
            this.extraFuncButton.Name = "extraFuncButton";
            this.extraFuncButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.extraFuncButton.OnDisabledState.BorderRadius = 1;
            this.extraFuncButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.extraFuncButton.OnDisabledState.BorderThickness = 1;
            this.extraFuncButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.extraFuncButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.extraFuncButton.OnDisabledState.IconLeftImage = null;
            this.extraFuncButton.OnDisabledState.IconRightImage = null;
            this.extraFuncButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.extraFuncButton.onHoverState.BorderRadius = 1;
            this.extraFuncButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.extraFuncButton.onHoverState.BorderThickness = 1;
            this.extraFuncButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.extraFuncButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.extraFuncButton.onHoverState.IconLeftImage = null;
            this.extraFuncButton.onHoverState.IconRightImage = null;
            this.extraFuncButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.extraFuncButton.OnIdleState.BorderRadius = 1;
            this.extraFuncButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.extraFuncButton.OnIdleState.BorderThickness = 1;
            this.extraFuncButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.extraFuncButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.extraFuncButton.OnIdleState.IconLeftImage = null;
            this.extraFuncButton.OnIdleState.IconRightImage = null;
            this.extraFuncButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.extraFuncButton.OnPressedState.BorderRadius = 1;
            this.extraFuncButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.extraFuncButton.OnPressedState.BorderThickness = 1;
            this.extraFuncButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.extraFuncButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.extraFuncButton.OnPressedState.IconLeftImage = null;
            this.extraFuncButton.OnPressedState.IconRightImage = null;
            this.extraFuncButton.Size = new System.Drawing.Size(122, 20);
            this.extraFuncButton.TabIndex = 42;
            this.extraFuncButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.extraFuncButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.extraFuncButton.TextMarginLeft = 0;
            this.extraFuncButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.extraFuncButton.UseDefaultRadiusAndThickness = true;
            this.extraFuncButton.Click += new System.EventHandler(this.extraFuncButton_Click);
            // 
            // mainFuncButton
            // 
            this.mainFuncButton.AllowAnimations = true;
            this.mainFuncButton.AllowMouseEffects = true;
            this.mainFuncButton.AllowToggling = true;
            this.mainFuncButton.AnimationSpeed = 200;
            this.mainFuncButton.AutoGenerateColors = false;
            this.mainFuncButton.AutoRoundBorders = false;
            this.mainFuncButton.AutoSizeLeftIcon = true;
            this.mainFuncButton.AutoSizeRightIcon = true;
            this.mainFuncButton.BackColor = System.Drawing.Color.Transparent;
            this.mainFuncButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.mainFuncButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mainFuncButton.BackgroundImage")));
            this.mainFuncButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.mainFuncButton.ButtonText = "Main Function";
            this.mainFuncButton.ButtonTextMarginLeft = 0;
            this.mainFuncButton.ColorContrastOnClick = 45;
            this.mainFuncButton.ColorContrastOnHover = 45;
            this.mainFuncButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.mainFuncButton.CustomizableEdges = borderEdges12;
            this.mainFuncButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.mainFuncButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.mainFuncButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.mainFuncButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.mainFuncButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.mainFuncButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mainFuncButton.ForeColor = System.Drawing.Color.DimGray;
            this.mainFuncButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mainFuncButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.mainFuncButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.mainFuncButton.IconMarginLeft = 11;
            this.mainFuncButton.IconPadding = 13;
            this.mainFuncButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mainFuncButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.mainFuncButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.mainFuncButton.IconSize = 25;
            this.mainFuncButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.mainFuncButton.IdleBorderRadius = 1;
            this.mainFuncButton.IdleBorderThickness = 1;
            this.mainFuncButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.mainFuncButton.IdleIconLeftImage = null;
            this.mainFuncButton.IdleIconRightImage = null;
            this.mainFuncButton.IndicateFocus = true;
            this.mainFuncButton.Location = new System.Drawing.Point(18, 6);
            this.mainFuncButton.Name = "mainFuncButton";
            this.mainFuncButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.mainFuncButton.OnDisabledState.BorderRadius = 1;
            this.mainFuncButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.mainFuncButton.OnDisabledState.BorderThickness = 1;
            this.mainFuncButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.mainFuncButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.mainFuncButton.OnDisabledState.IconLeftImage = null;
            this.mainFuncButton.OnDisabledState.IconRightImage = null;
            this.mainFuncButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.mainFuncButton.onHoverState.BorderRadius = 1;
            this.mainFuncButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.mainFuncButton.onHoverState.BorderThickness = 1;
            this.mainFuncButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.mainFuncButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.mainFuncButton.onHoverState.IconLeftImage = null;
            this.mainFuncButton.onHoverState.IconRightImage = null;
            this.mainFuncButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.mainFuncButton.OnIdleState.BorderRadius = 1;
            this.mainFuncButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.mainFuncButton.OnIdleState.BorderThickness = 1;
            this.mainFuncButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.mainFuncButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.mainFuncButton.OnIdleState.IconLeftImage = null;
            this.mainFuncButton.OnIdleState.IconRightImage = null;
            this.mainFuncButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.mainFuncButton.OnPressedState.BorderRadius = 1;
            this.mainFuncButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.mainFuncButton.OnPressedState.BorderThickness = 1;
            this.mainFuncButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.mainFuncButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.mainFuncButton.OnPressedState.IconLeftImage = null;
            this.mainFuncButton.OnPressedState.IconRightImage = null;
            this.mainFuncButton.Size = new System.Drawing.Size(122, 20);
            this.mainFuncButton.TabIndex = 41;
            this.mainFuncButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mainFuncButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.mainFuncButton.TextMarginLeft = 0;
            this.mainFuncButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.mainFuncButton.UseDefaultRadiusAndThickness = true;
            this.mainFuncButton.Click += new System.EventHandler(this.mainFuncButton_Click);
            // 
            // topbarPanel
            // 
            this.topbarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(205)))), ((int)(((byte)(182)))));
            this.topbarPanel.BackgroundColor = System.Drawing.Color.Silver;
            this.topbarPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("topbarPanel.BackgroundImage")));
            this.topbarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.topbarPanel.BorderColor = System.Drawing.Color.Transparent;
            this.topbarPanel.BorderRadius = 3;
            this.topbarPanel.BorderThickness = 1;
            this.topbarPanel.Controls.Add(this.exitButton);
            this.topbarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topbarPanel.Location = new System.Drawing.Point(0, 0);
            this.topbarPanel.Name = "topbarPanel";
            this.topbarPanel.ShowBorders = true;
            this.topbarPanel.Size = new System.Drawing.Size(816, 27);
            this.topbarPanel.TabIndex = 4;
            // 
            // exitButton
            // 
            this.exitButton.AllowAnimations = true;
            this.exitButton.AllowMouseEffects = true;
            this.exitButton.AllowToggling = false;
            this.exitButton.AnimationSpeed = 200;
            this.exitButton.AutoGenerateColors = false;
            this.exitButton.AutoRoundBorders = false;
            this.exitButton.AutoSizeLeftIcon = true;
            this.exitButton.AutoSizeRightIcon = true;
            this.exitButton.BackColor = System.Drawing.Color.Transparent;
            this.exitButton.BackColor1 = System.Drawing.Color.Transparent;
            this.exitButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exitButton.BackgroundImage")));
            this.exitButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.ButtonText = "";
            this.exitButton.ButtonTextMarginLeft = 0;
            this.exitButton.ColorContrastOnClick = 45;
            this.exitButton.ColorContrastOnHover = 45;
            this.exitButton.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges13.BottomLeft = true;
            borderEdges13.BottomRight = true;
            borderEdges13.TopLeft = true;
            borderEdges13.TopRight = true;
            this.exitButton.CustomizableEdges = borderEdges13;
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.exitButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.exitButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.exitButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.exitButton.Dock = System.Windows.Forms.DockStyle.Left;
            this.exitButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.exitButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.exitButton.ForeColor = System.Drawing.Color.White;
            this.exitButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.exitButton.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.exitButton.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.exitButton.IconMarginLeft = 11;
            this.exitButton.IconPadding = 5;
            this.exitButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.exitButton.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.exitButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.exitButton.IconSize = 25;
            this.exitButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.exitButton.IdleBorderRadius = 1;
            this.exitButton.IdleBorderThickness = 1;
            this.exitButton.IdleFillColor = System.Drawing.Color.Transparent;
            this.exitButton.IdleIconLeftImage = global::Warehouse.Properties.Resources.exit_circle2;
            this.exitButton.IdleIconRightImage = null;
            this.exitButton.IndicateFocus = false;
            this.exitButton.Location = new System.Drawing.Point(0, 0);
            this.exitButton.Name = "exitButton";
            this.exitButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.exitButton.OnDisabledState.BorderRadius = 1;
            this.exitButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.OnDisabledState.BorderThickness = 1;
            this.exitButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.exitButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.exitButton.OnDisabledState.IconLeftImage = null;
            this.exitButton.OnDisabledState.IconRightImage = null;
            this.exitButton.onHoverState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.exitButton.onHoverState.BorderRadius = 1;
            this.exitButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.onHoverState.BorderThickness = 1;
            this.exitButton.onHoverState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.exitButton.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.exitButton.onHoverState.IconLeftImage = null;
            this.exitButton.onHoverState.IconRightImage = null;
            this.exitButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.exitButton.OnIdleState.BorderRadius = 1;
            this.exitButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.OnIdleState.BorderThickness = 1;
            this.exitButton.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.exitButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.exitButton.OnIdleState.IconLeftImage = global::Warehouse.Properties.Resources.exit_circle2;
            this.exitButton.OnIdleState.IconRightImage = null;
            this.exitButton.OnPressedState.BorderColor = System.Drawing.Color.Transparent;
            this.exitButton.OnPressedState.BorderRadius = 1;
            this.exitButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.OnPressedState.BorderThickness = 1;
            this.exitButton.OnPressedState.FillColor = System.Drawing.Color.Transparent;
            this.exitButton.OnPressedState.ForeColor = System.Drawing.Color.Transparent;
            this.exitButton.OnPressedState.IconLeftImage = null;
            this.exitButton.OnPressedState.IconRightImage = null;
            this.exitButton.Size = new System.Drawing.Size(27, 27);
            this.exitButton.TabIndex = 7;
            this.exitButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.exitButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.exitButton.TextMarginLeft = 0;
            this.exitButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.exitButton.UseDefaultRadiusAndThickness = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // AddFileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 484);
            this.Controls.Add(this.panelSettings);
            this.Controls.Add(this.secondTopPanel);
            this.Controls.Add(this.topbarPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(816, 484);
            this.MinimumSize = new System.Drawing.Size(816, 484);
            this.Name = "AddFileForm";
            this.Text = "Add Data";
            this.Load += new System.EventHandler(this.AddFileForm_Load);
            this.controlPage.ResumeLayout(false);
            this.mainFunc.ResumeLayout(false);
            this.mainFunc.PerformLayout();
            this.extraFunc.ResumeLayout(false);
            this.extraFunc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageFileBox)).EndInit();
            this.panelSettings.ResumeLayout(false);
            this.secondTopPanel.ResumeLayout(false);
            this.topbarPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock;
        private Bunifu.UI.WinForms.BunifuPanel secondTopPanel;
        private Bunifu.UI.WinForms.BunifuPanel topbarPanel;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton exitButton;
        private Bunifu.UI.WinForms.BunifuShadowPanel panelSettings;
        private Bunifu.UI.WinForms.BunifuPages controlPage;
        private System.Windows.Forms.TabPage extraFunc;
        private System.Windows.Forms.TabPage mainFunc;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton cancelButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton okButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton applyButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton randomUcnButton;
        private Bunifu.UI.WinForms.BunifuLabel discountLabel;
        private Bunifu.UI.WinForms.BunifuTextBox discountTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel statusLabel;
        private Bunifu.UI.WinForms.BunifuDropdown statusDropdown;
        private Bunifu.UI.WinForms.BunifuLabel warrantyLabel;
        private Bunifu.UI.WinForms.BunifuDropdown warrantyDropdown;
        private Bunifu.UI.WinForms.BunifuSeparator bunifuSeparator1;
        private Bunifu.UI.WinForms.BunifuLabel currencyLabel;
        private Bunifu.UI.WinForms.BunifuDropdown currencyDropdown;
        private Bunifu.UI.WinForms.BunifuTextBox firstCostTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel costLabel;
        private Bunifu.UI.WinForms.BunifuTextBox amountTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel amountLabel;
        private Bunifu.UI.WinForms.BunifuSeparator separator;
        private Bunifu.UI.WinForms.BunifuDropdown countryDropdown;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel companyLabel;
        private Bunifu.UI.WinForms.BunifuTextBox ucnTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel ucnLabel;
        private Bunifu.UI.WinForms.BunifuLabel codeLabel;
        private Bunifu.UI.WinForms.BunifuTextBox codeTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel nameLabel;
        private Bunifu.UI.WinForms.BunifuTextBox nameTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel descriptionLabel;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton editImageButton;
        private Bunifu.UI.WinForms.BunifuLabel imageLabel;
        private Bunifu.UI.WinForms.BunifuPictureBox imageFileBox;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton extraFuncButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton mainFuncButton;
        private System.Windows.Forms.RichTextBox descriptionTxtBox;
        private Bunifu.UI.WinForms.BunifuLabel resultDiscountLabel;
        private Bunifu.UI.WinForms.BunifuTextBox companyTxtBox;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton randomNameButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton digitsRandomButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton countryRandomButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton codeRandomButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton booleanRandomButton;
    }
}