﻿
namespace Warehouse
{
    partial class EditTreeName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditTreeName));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.nameLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuFormDock = new Bunifu.UI.WinForms.BunifuFormDock();
            this.okButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.nameTxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.topbarPanel = new Bunifu.UI.WinForms.BunifuPanel();
            this.exitButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.topbarPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AllowParentOverrides = false;
            this.nameLabel.AutoEllipsis = false;
            this.nameLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.nameLabel.CursorType = System.Windows.Forms.Cursors.Default;
            this.nameLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.nameLabel.Location = new System.Drawing.Point(12, 56);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nameLabel.Size = new System.Drawing.Size(117, 21);
            this.nameLabel.TabIndex = 7;
            this.nameLabel.Text = "TreeNode Name:";
            this.nameLabel.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.nameLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuFormDock
            // 
            this.bunifuFormDock.AllowFormDragging = true;
            this.bunifuFormDock.AllowFormDropShadow = true;
            this.bunifuFormDock.AllowFormResizing = true;
            this.bunifuFormDock.AllowHidingBottomRegion = true;
            this.bunifuFormDock.AllowOpacityChangesWhileDragging = false;
            this.bunifuFormDock.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock.ContainerControl = this;
            this.bunifuFormDock.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock.DockingOptions.DockAll = true;
            this.bunifuFormDock.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock.DockingOptions.DockLeft = true;
            this.bunifuFormDock.DockingOptions.DockRight = true;
            this.bunifuFormDock.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock.DockingOptions.DockTopRight = true;
            this.bunifuFormDock.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock.ParentForm = this;
            this.bunifuFormDock.ShowCursorChanges = true;
            this.bunifuFormDock.ShowDockingIndicators = true;
            this.bunifuFormDock.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock.TitleBarOptions.BunifuFormDock = this.bunifuFormDock;
            this.bunifuFormDock.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // okButton
            // 
            this.okButton.AllowAnimations = true;
            this.okButton.AllowMouseEffects = true;
            this.okButton.AllowToggling = true;
            this.okButton.AnimationSpeed = 200;
            this.okButton.AutoGenerateColors = false;
            this.okButton.AutoRoundBorders = false;
            this.okButton.AutoSizeLeftIcon = true;
            this.okButton.AutoSizeRightIcon = true;
            this.okButton.BackColor = System.Drawing.Color.Transparent;
            this.okButton.BackColor1 = System.Drawing.Color.Gainsboro;
            this.okButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("okButton.BackgroundImage")));
            this.okButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.ButtonText = "OK";
            this.okButton.ButtonTextMarginLeft = 0;
            this.okButton.ColorContrastOnClick = 45;
            this.okButton.ColorContrastOnHover = 45;
            this.okButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.okButton.CustomizableEdges = borderEdges1;
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.okButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.okButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.okButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.okButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.okButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.okButton.ForeColor = System.Drawing.Color.DimGray;
            this.okButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.okButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.okButton.IconLeftPadding = new System.Windows.Forms.Padding(12, 3, 3, 3);
            this.okButton.IconMarginLeft = 11;
            this.okButton.IconPadding = 13;
            this.okButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.okButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.okButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.okButton.IconSize = 25;
            this.okButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.okButton.IdleBorderRadius = 1;
            this.okButton.IdleBorderThickness = 1;
            this.okButton.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.okButton.IdleIconLeftImage = null;
            this.okButton.IdleIconRightImage = null;
            this.okButton.IndicateFocus = true;
            this.okButton.Location = new System.Drawing.Point(439, 102);
            this.okButton.Name = "okButton";
            this.okButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.okButton.OnDisabledState.BorderRadius = 1;
            this.okButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.OnDisabledState.BorderThickness = 1;
            this.okButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.okButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.okButton.OnDisabledState.IconLeftImage = null;
            this.okButton.OnDisabledState.IconRightImage = null;
            this.okButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.okButton.onHoverState.BorderRadius = 1;
            this.okButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.onHoverState.BorderThickness = 1;
            this.okButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.okButton.onHoverState.ForeColor = System.Drawing.Color.LightSalmon;
            this.okButton.onHoverState.IconLeftImage = null;
            this.okButton.onHoverState.IconRightImage = null;
            this.okButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.okButton.OnIdleState.BorderRadius = 1;
            this.okButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.OnIdleState.BorderThickness = 1;
            this.okButton.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.okButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.okButton.OnIdleState.IconLeftImage = null;
            this.okButton.OnIdleState.IconRightImage = null;
            this.okButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.okButton.OnPressedState.BorderRadius = 1;
            this.okButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.okButton.OnPressedState.BorderThickness = 1;
            this.okButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.okButton.OnPressedState.ForeColor = System.Drawing.Color.LightSalmon;
            this.okButton.OnPressedState.IconLeftImage = null;
            this.okButton.OnPressedState.IconRightImage = null;
            this.okButton.Size = new System.Drawing.Size(122, 25);
            this.okButton.TabIndex = 41;
            this.okButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.okButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.okButton.TextMarginLeft = 0;
            this.okButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.okButton.UseDefaultRadiusAndThickness = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // nameTxtBox
            // 
            this.nameTxtBox.AcceptsReturn = false;
            this.nameTxtBox.AcceptsTab = false;
            this.nameTxtBox.AnimationSpeed = 200;
            this.nameTxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.nameTxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.nameTxtBox.BackColor = System.Drawing.Color.White;
            this.nameTxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("nameTxtBox.BackgroundImage")));
            this.nameTxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.nameTxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.nameTxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.nameTxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.nameTxtBox.BorderRadius = 1;
            this.nameTxtBox.BorderThickness = 1;
            this.nameTxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.nameTxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxtBox.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.nameTxtBox.DefaultText = "";
            this.nameTxtBox.FillColor = System.Drawing.Color.White;
            this.nameTxtBox.HideSelection = true;
            this.nameTxtBox.IconLeft = null;
            this.nameTxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxtBox.IconPadding = 10;
            this.nameTxtBox.IconRight = null;
            this.nameTxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxtBox.Lines = new string[0];
            this.nameTxtBox.Location = new System.Drawing.Point(135, 56);
            this.nameTxtBox.MaxLength = 32767;
            this.nameTxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.nameTxtBox.Modified = false;
            this.nameTxtBox.Multiline = false;
            this.nameTxtBox.Name = "nameTxtBox";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.nameTxtBox.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.nameTxtBox.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.nameTxtBox.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.nameTxtBox.OnIdleState = stateProperties4;
            this.nameTxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.nameTxtBox.PasswordChar = '\0';
            this.nameTxtBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.nameTxtBox.PlaceholderText = "Enter treenode name";
            this.nameTxtBox.ReadOnly = false;
            this.nameTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.nameTxtBox.SelectedText = "";
            this.nameTxtBox.SelectionLength = 0;
            this.nameTxtBox.SelectionStart = 0;
            this.nameTxtBox.ShortcutsEnabled = true;
            this.nameTxtBox.Size = new System.Drawing.Size(426, 25);
            this.nameTxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.nameTxtBox.TabIndex = 6;
            this.nameTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.nameTxtBox.TextMarginBottom = 0;
            this.nameTxtBox.TextMarginLeft = 3;
            this.nameTxtBox.TextMarginTop = 0;
            this.nameTxtBox.TextPlaceholder = "Enter treenode name";
            this.nameTxtBox.UseSystemPasswordChar = false;
            this.nameTxtBox.WordWrap = true;
            // 
            // topbarPanel
            // 
            this.topbarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(205)))), ((int)(((byte)(182)))));
            this.topbarPanel.BackgroundColor = System.Drawing.Color.Silver;
            this.topbarPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("topbarPanel.BackgroundImage")));
            this.topbarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.topbarPanel.BorderColor = System.Drawing.Color.Transparent;
            this.topbarPanel.BorderRadius = 3;
            this.topbarPanel.BorderThickness = 1;
            this.topbarPanel.Controls.Add(this.exitButton);
            this.topbarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topbarPanel.Location = new System.Drawing.Point(0, 0);
            this.topbarPanel.Name = "topbarPanel";
            this.topbarPanel.ShowBorders = true;
            this.topbarPanel.Size = new System.Drawing.Size(577, 27);
            this.topbarPanel.TabIndex = 5;
            // 
            // exitButton
            // 
            this.exitButton.AllowAnimations = true;
            this.exitButton.AllowMouseEffects = true;
            this.exitButton.AllowToggling = false;
            this.exitButton.AnimationSpeed = 200;
            this.exitButton.AutoGenerateColors = false;
            this.exitButton.AutoRoundBorders = false;
            this.exitButton.AutoSizeLeftIcon = true;
            this.exitButton.AutoSizeRightIcon = true;
            this.exitButton.BackColor = System.Drawing.Color.Transparent;
            this.exitButton.BackColor1 = System.Drawing.Color.Transparent;
            this.exitButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exitButton.BackgroundImage")));
            this.exitButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.ButtonText = "";
            this.exitButton.ButtonTextMarginLeft = 0;
            this.exitButton.ColorContrastOnClick = 45;
            this.exitButton.ColorContrastOnHover = 45;
            this.exitButton.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.exitButton.CustomizableEdges = borderEdges2;
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.exitButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.exitButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.exitButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.exitButton.Dock = System.Windows.Forms.DockStyle.Left;
            this.exitButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.exitButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.exitButton.ForeColor = System.Drawing.Color.White;
            this.exitButton.IconLeftAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.exitButton.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.exitButton.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.exitButton.IconMarginLeft = 11;
            this.exitButton.IconPadding = 5;
            this.exitButton.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.exitButton.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.exitButton.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.exitButton.IconSize = 25;
            this.exitButton.IdleBorderColor = System.Drawing.Color.Transparent;
            this.exitButton.IdleBorderRadius = 1;
            this.exitButton.IdleBorderThickness = 1;
            this.exitButton.IdleFillColor = System.Drawing.Color.Transparent;
            this.exitButton.IdleIconLeftImage = global::Warehouse.Properties.Resources.exit_circle2;
            this.exitButton.IdleIconRightImage = null;
            this.exitButton.IndicateFocus = false;
            this.exitButton.Location = new System.Drawing.Point(0, 0);
            this.exitButton.Name = "exitButton";
            this.exitButton.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.exitButton.OnDisabledState.BorderRadius = 1;
            this.exitButton.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.OnDisabledState.BorderThickness = 1;
            this.exitButton.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.exitButton.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.exitButton.OnDisabledState.IconLeftImage = null;
            this.exitButton.OnDisabledState.IconRightImage = null;
            this.exitButton.onHoverState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.exitButton.onHoverState.BorderRadius = 1;
            this.exitButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.onHoverState.BorderThickness = 1;
            this.exitButton.onHoverState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.exitButton.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.exitButton.onHoverState.IconLeftImage = null;
            this.exitButton.onHoverState.IconRightImage = null;
            this.exitButton.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.exitButton.OnIdleState.BorderRadius = 1;
            this.exitButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.OnIdleState.BorderThickness = 1;
            this.exitButton.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.exitButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.exitButton.OnIdleState.IconLeftImage = global::Warehouse.Properties.Resources.exit_circle2;
            this.exitButton.OnIdleState.IconRightImage = null;
            this.exitButton.OnPressedState.BorderColor = System.Drawing.Color.Transparent;
            this.exitButton.OnPressedState.BorderRadius = 1;
            this.exitButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.exitButton.OnPressedState.BorderThickness = 1;
            this.exitButton.OnPressedState.FillColor = System.Drawing.Color.Transparent;
            this.exitButton.OnPressedState.ForeColor = System.Drawing.Color.Transparent;
            this.exitButton.OnPressedState.IconLeftImage = null;
            this.exitButton.OnPressedState.IconRightImage = null;
            this.exitButton.Size = new System.Drawing.Size(27, 27);
            this.exitButton.TabIndex = 7;
            this.exitButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.exitButton.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.exitButton.TextMarginLeft = 0;
            this.exitButton.TextPadding = new System.Windows.Forms.Padding(0);
            this.exitButton.UseDefaultRadiusAndThickness = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // EditTreeName
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 155);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.nameTxtBox);
            this.Controls.Add(this.topbarPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(577, 155);
            this.MinimumSize = new System.Drawing.Size(577, 155);
            this.Name = "EditTreeName";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditTreeName";
            this.topbarPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuPanel topbarPanel;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton exitButton;
        private Bunifu.UI.WinForms.BunifuLabel nameLabel;
        private Bunifu.UI.WinForms.BunifuTextBox nameTxtBox;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton okButton;
        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock;
    }
}